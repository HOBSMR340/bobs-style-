import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import { StoreProvider } from "./store";
import { Layout } from "./components/Layout";
import Home from "./pages/Home";
import Shop from "./pages/Shop";
import ProductPage from "./pages/Product";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import Account, { Wishlist } from "./pages/Account";
import OrderSuccess from "./pages/OrderSuccess";
import AdminLayout, { AdminLogin } from "./admin/AdminLayout";
import Dashboard from "./admin/Dashboard";
import AdminProducts, { ProductForm } from "./admin/Products";
import { AdminCustomers, AdminInventory, AdminOrders, AdminPrices, AdminReports } from "./admin/Ops";
import { AdminActivity, AdminSettings, AdminUsers } from "./admin/Config";

export default function App() {
  return (
    <StoreProvider>
      <HashRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/shop/:category" element={<Shop />} />
            <Route path="/product/:id" element={<ProductPage />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/account" element={<Account />} />
            <Route path="/wishlist" element={<Wishlist />} />
            <Route path="/order/:id" element={<OrderSuccess />} />
          </Route>
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="products" element={<AdminProducts />} />
            <Route path="products/new" element={<ProductForm />} />
            <Route path="products/:id" element={<ProductForm />} />
            <Route path="inventory" element={<AdminInventory />} />
            <Route path="prices" element={<AdminPrices />} />
            <Route path="orders" element={<AdminOrders />} />
            <Route path="customers" element={<AdminCustomers />} />
            <Route path="reports" element={<AdminReports />} />
            <Route path="settings" element={<AdminSettings />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="activity" element={<AdminActivity />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </HashRouter>
    </StoreProvider>
  );
}
