import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  BarChart,
  Bar,
} from "recharts";
import { useStore } from "../store";
import { productStock } from "../utils/helpers";
import type { OrderStatus } from "../types";

const RANGES = [
  { id: "1", key: "range.today", days: 1 },
  { id: "7", key: "range.7", days: 7 },
  { id: "30", key: "range.30", days: 30 },
  { id: "90", key: "range.90", days: 90 },
  { id: "180", key: "range.180", days: 180 },
  { id: "365", key: "range.365", days: 365 },
];

export default function Dashboard() {
  const s = useStore();
  const [days, setDays] = useState(30);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const filtered = useMemo(() => {
    const start = from ? new Date(from) : new Date(Date.now() - days * 86400000);
    const end = to ? new Date(to + "T23:59:59") : new Date();
    start.setHours(0, 0, 0, 0);
    return s.orders.filter((o) => {
      const d = new Date(o.createdAt);
      return d >= start && d <= end && o.status !== "cancelled";
    });
  }, [s.orders, days, from, to]);

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const weekStart = new Date(Date.now() - 7 * 86400000);
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const paid = (list: typeof s.orders) => list.filter((o) => o.status !== "cancelled" && o.status !== "returned");
  const sum = (list: typeof s.orders) => paid(list).reduce((n, o) => n + o.total, 0);
  const today = s.orders.filter((o) => new Date(o.createdAt) >= todayStart);
  const week = s.orders.filter((o) => new Date(o.createdAt) >= weekStart);
  const month = s.orders.filter((o) => new Date(o.createdAt) >= monthStart);

  const itemsSold = filtered.reduce((n, o) => n + o.items.reduce((x, i) => x + i.quantity, 0), 0);
  const aov = filtered.length ? sum(filtered) / filtered.length : 0;
  const low = s.products.filter((p) => p.variants.some((v) => v.stock > 0 && v.stock <= v.minStock));
  const oos = s.products.filter((p) => productStock(p) === 0 || p.status === "out_of_stock");

  const byDay = useMemo(() => {
    const map: Record<string, number> = {};
    filtered.forEach((o) => {
      const k = o.createdAt.slice(0, 10);
      map[k] = (map[k] || 0) + o.total;
    });
    return Object.entries(map)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, total]) => ({ date: date.slice(5), total }));
  }, [filtered]);

  const statuses: OrderStatus[] = ["new", "confirmed", "preparing", "shipped", "delivered", "cancelled", "returned"];
  const byStatus = statuses.map((st) => ({
    name: s.t(`order.${st}`),
    value: s.orders.filter((o) => o.status === st).length,
  }));
  const COLORS = ["#c4a574", "#1a1a1a", "#6b6560", "#8b2e2e", "#3d5a3d", "#888", "#b45309"];

  const byCat = s.categories
    .filter((c) => !c.parentId)
    .map((c) => {
      const value = filtered.reduce((n, o) => {
        return (
          n +
          o.items.reduce((x, it) => {
            const p = s.products.find((pp) => pp.id === it.productId);
            return p?.categoryId === c.id ? x + it.total : x;
          }, 0)
        );
      }, 0);
      return { name: s.tr(c.name), value };
    });

  const topMap: Record<string, { name: string; qty: number; img: string }> = {};
  filtered.forEach((o) =>
    o.items.forEach((it) => {
      if (!topMap[it.productId]) topMap[it.productId] = { name: s.tr(it.name), qty: 0, img: it.image };
      topMap[it.productId].qty += it.quantity;
    })
  );
  const top = Object.values(topMap)
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 6);

  const kpi = [
    { l: s.t("dash.today"), v: s.formatPrice(sum(today)) },
    { l: s.t("dash.week"), v: s.formatPrice(sum(week)) },
    { l: s.t("dash.month"), v: s.formatPrice(sum(month)) },
    { l: s.t("dash.orders"), v: String(filtered.length) },
    { l: s.t("dash.customers"), v: String(s.customers.length) },
    { l: s.t("dash.aov"), v: s.formatPrice(aov) },
    { l: s.t("dash.sold"), v: String(itemsSold) },
    { l: s.t("dash.oos"), v: String(oos.length) },
    { l: s.t("dash.low"), v: String(low.length) },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-serif text-3xl">{s.t("admin.dashboard")}</h1>
        <div className="flex flex-wrap gap-2">
          {RANGES.map((r) => (
            <button
              key={r.id}
              onClick={() => {
                setDays(r.days);
                setFrom("");
                setTo("");
              }}
              className={`px-3 py-1 text-[11px] uppercase tracking-widest ${days === r.days && !from ? "bg-ink text-white" : "border border-black/15"}`}
            >
              {s.t(r.key)}
            </button>
          ))}
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="border border-black/15 bg-transparent px-2 py-1 text-xs" />
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="border border-black/15 bg-transparent px-2 py-1 text-xs" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        {kpi.map((k) => (
          <div key={k.l} className="border border-black/10 bg-white p-4">
            <p className="text-[10px] uppercase tracking-[0.18em] text-mute">{k.l}</p>
            <p className="mt-2 font-serif text-2xl">{k.v}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="border border-black/10 bg-white p-4 lg:col-span-2">
          <p className="mb-4 text-[11px] uppercase tracking-widest">{s.t("dash.salesDay")}</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={byDay}>
                <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Area type="monotone" dataKey="total" stroke="#c4a574" fill="#c4a57433" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="border border-black/10 bg-white p-4">
          <p className="mb-4 text-[11px] uppercase tracking-widest">{s.t("dash.byStatus")}</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={byStatus} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80}>
                  {byStatus.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="border border-black/10 bg-white p-4">
          <p className="mb-4 text-[11px] uppercase tracking-widest">{s.t("dash.byCat")}</p>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byCat}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="value" fill="#1a1a1a" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="border border-black/10 bg-white p-4">
          <p className="mb-4 text-[11px] uppercase tracking-widest">{s.t("dash.top")}</p>
          <ul className="space-y-3">
            {top.map((t) => (
              <li key={t.name} className="flex items-center gap-3">
                <img src={t.img} className="h-12 w-10 object-cover" alt="" />
                <span className="flex-1 text-sm">{t.name}</span>
                <span className="text-xs text-mute">{t.qty}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {(low.length > 0 || oos.length > 0) && (
        <div className="grid gap-4 md:grid-cols-2">
          <AlertBox title={s.t("dash.low")} items={low.map((p) => s.tr(p.name))} to="/admin/inventory" />
          <AlertBox title={s.t("dash.oos")} items={oos.map((p) => s.tr(p.name))} to="/admin/inventory" />
        </div>
      )}
    </div>
  );
}

function AlertBox({ title, items, to }: { title: string; items: string[]; to: string }) {
  const s = useStore();
  return (
    <div className="border border-[#8b2e2e]/20 bg-white p-4">
      <div className="flex justify-between">
        <p className="text-[11px] uppercase tracking-widest text-[#8b2e2e]">{title}</p>
        <Link to={to} className="text-xs underline">
          {s.t("common.view")}
        </Link>
      </div>
      <ul className="mt-2 text-sm">
        {items.slice(0, 6).map((n) => (
          <li key={n}>· {n}</li>
        ))}
      </ul>
    </div>
  );
}
