import { NavLink, Outlet, useNavigate, Navigate } from "react-router-dom";
import {
  LayoutDashboard,
  Package,
  Warehouse,
  BadgeDollarSign,
  ShoppingBag,
  Users,
  BarChart3,
  Settings,
  Shield,
  ScrollText,
  LogOut,
  Store,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";
import { useStore } from "../store";
import type { Permission } from "../types";
import { AdminGuard } from "./Guard";

const LINKS: { to: string; key: string; icon: typeof Package; perm: Permission }[] = [
  { to: "/admin", key: "admin.dashboard", icon: LayoutDashboard, perm: "dashboard" },
  { to: "/admin/products", key: "admin.products", icon: Package, perm: "products" },
  { to: "/admin/inventory", key: "admin.stock", icon: Warehouse, perm: "stock" },
  { to: "/admin/prices", key: "admin.prices", icon: BadgeDollarSign, perm: "prices" },
  { to: "/admin/orders", key: "admin.orders", icon: ShoppingBag, perm: "orders" },
  { to: "/admin/customers", key: "admin.customers", icon: Users, perm: "customers" },
  { to: "/admin/reports", key: "admin.reports", icon: BarChart3, perm: "reports" },
  { to: "/admin/settings", key: "admin.settings", icon: Settings, perm: "settings" },
  { to: "/admin/users", key: "admin.users", icon: Shield, perm: "users" },
  { to: "/admin/activity", key: "admin.activity", icon: ScrollText, perm: "activity" },
];

export default function AdminLayout() {
  const s = useStore();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);

  if (!s.currentUser) return <Navigate to="/admin/login" replace />;

  const links = LINKS.filter((l) => s.hasPermission(l.perm));

  return (
    <div className="min-h-screen bg-[#f3efe8] text-ink">
      <div className="flex">
        <aside className={`fixed inset-y-0 start-0 z-40 w-64 border-e border-black/10 bg-[#161412] text-[#f3eee6] transition lg:static ${open ? "translate-x-0" : "ltr:-translate-x-full rtl:translate-x-full lg:translate-x-0 lg:rtl:translate-x-0"}`}>
          <div className="flex h-16 items-center justify-between px-5">
            <span className="font-serif text-xl tracking-[0.3em]">{s.tr(s.settings.storeName)}</span>
            <button className="lg:hidden" onClick={() => setOpen(false)}>
              <X className="h-5 w-5" />
            </button>
          </div>
          <nav className="space-y-0.5 px-3 py-4 pb-28">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/admin"}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2 text-[13px] ${isActive ? "bg-white/10 text-[#c4a574]" : "text-white/70 hover:bg-white/5"}`
                }
              >
                <l.icon className="h-4 w-4" />
                {s.t(l.key)}
              </NavLink>
            ))}
          </nav>
          <div className="absolute inset-x-0 bottom-0 border-t border-white/10 p-4 text-xs text-white/50">
            <p>{s.currentUser.name}</p>
            <p>{s.t(`role.${s.currentUser.role}`)}</p>
          </div>
        </aside>
        <div className="min-h-screen flex-1">
          <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-black/10 bg-[#f3efe8]/90 px-4 backdrop-blur">
            <button className="lg:hidden" onClick={() => setOpen(true)}>
              <Menu />
            </button>
            <p className="hidden text-sm text-mute sm:block">{s.t("demo.hint")}</p>
            <div className="flex items-center gap-3">
              <select
                value={s.lang}
                onChange={(e) => s.setLang(e.target.value as "fr" | "ar" | "en")}
                className="border border-black/10 bg-transparent px-2 py-1 text-xs"
              >
                <option value="fr">FR</option>
                <option value="ar">AR</option>
                <option value="en">EN</option>
              </select>
              <NotifBell />
              <button onClick={() => nav("/")} className="flex items-center gap-1 text-xs">
                <Store className="h-4 w-4" /> {s.t("admin.storefront")}
              </button>
              <button
                onClick={() => {
                  s.logoutAdmin();
                  nav("/admin/login");
                }}
                className="p-1"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </header>
          <div className="p-4 lg:p-8">
            <AdminGuard>
              <Outlet />
            </AdminGuard>
          </div>
        </div>
      </div>
    </div>
  );
}

function NotifBell() {
  const s = useStore();
  const [open, setOpen] = useState(false);
  const unread = s.notifications.filter((n) => !n.read).length;
  return (
    <div className="relative">
      <button className="relative p-1" title="notifications" onClick={() => setOpen((v) => !v)}>
        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.73 21a2 2 0 0 1-3.46 0" />
        </svg>
        {unread > 0 && <span className="absolute -end-0.5 -top-0.5 h-2 w-2 rounded-full bg-[#8b2e2e]" />}
      </button>
      {open && (
        <div className="absolute end-0 top-8 z-50 w-72 border border-black/10 bg-white p-3 text-sm shadow-xl">
          {s.notifications.length === 0 && <p className="text-mute">{s.t("common.empty")}</p>}
          {s.notifications.slice(0, 8).map((n) => (
            <button
              key={n.id}
              className={`mb-2 block w-full text-start ${n.read ? "text-mute" : "font-medium"}`}
              onClick={() => {
                s.markNotifRead(n.id);
                setOpen(false);
              }}
            >
              <p>{s.tr(n.title)}</p>
              <p className="text-xs text-mute">{s.tr(n.message)}</p>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function AdminLogin() {
  const s = useStore();
  const nav = useNavigate();
  const [email, setEmail] = useState("admin@velora.com");
  const [password, setPassword] = useState("admin123");
  const [err, setErr] = useState("");

  if (s.currentUser) return <Navigate to="/admin" replace />;

  const accounts = [
    { email: "admin@velora.com", password: "admin123", role: "super_admin", name: "Amine Bennani" },
    { email: "manager@velora.com", password: "manager123", role: "manager", name: "Lina Haddad" },
    { email: "vendeur@velora.com", password: "vendeur123", role: "seller", name: "Karim Saïdi" },
    { email: "stock@velora.com", password: "stock123", role: "stock_manager", name: "Nadia Cherif" },
  ];

  const enter = (em: string, pw: string) => {
    const u = s.loginAdmin(em, pw);
    if (!u) setErr(s.t("auth.error"));
    else nav("/admin");
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#161412] px-4 py-12 text-[#f3eee6]">
      <div className="w-full max-w-lg">
        <p className="text-center font-serif text-4xl tracking-[0.35em]">VELORA</p>
        <p className="mt-2 text-center text-[11px] uppercase tracking-[0.3em] text-[#c4a574]">{s.t("auth.adminLogin")}</p>

        <form
          className="mt-10"
          onSubmit={(e) => {
            e.preventDefault();
            enter(email, password);
          }}
        >
          <label className="block text-[11px] uppercase tracking-widest text-white/50">{s.t("checkout.email")}</label>
          <input className="mt-1 w-full border border-white/20 bg-transparent px-3 py-2.5" value={email} onChange={(e) => setEmail(e.target.value)} />
          <label className="mt-4 block text-[11px] uppercase tracking-widest text-white/50">{s.t("auth.password")}</label>
          <input type="password" className="mt-1 w-full border border-white/20 bg-transparent px-3 py-2.5" value={password} onChange={(e) => setPassword(e.target.value)} />
          {err && <p className="mt-2 text-sm text-red-400">{err}</p>}
          <button className="mt-6 w-full bg-[#c4a574] py-3 text-[11px] tracking-[0.22em] text-ink">{s.t("auth.login").toUpperCase()}</button>
        </form>

        <p className="mt-10 text-center text-[10px] uppercase tracking-[0.25em] text-white/40">
          {s.lang === "ar" ? "حسابات تجريبية — انقر للدخول" : s.lang === "en" ? "Demo accounts — click to enter" : "Comptes démo — cliquez pour entrer"}
        </p>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {accounts.map((a) => (
            <button
              key={a.email}
              type="button"
              onClick={() => enter(a.email, a.password)}
              className="border border-white/15 p-4 text-start hover:border-[#c4a574] hover:bg-white/5"
            >
              <p className="text-[10px] uppercase tracking-widest text-[#c4a574]">{s.t(`role.${a.role}`)}</p>
              <p className="mt-1 text-sm">{a.name}</p>
              <p className="mt-1 text-[11px] text-white/50">{a.email}</p>
              <p className="text-[11px] text-white/30">{a.password}</p>
            </button>
          ))}
        </div>
        <button onClick={() => nav("/")} className="mt-8 w-full text-center text-xs text-white/40 underline">
          ← {s.t("admin.storefront")}
        </button>
      </div>
    </div>
  );
}
