import { useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Copy, EyeOff, Pencil, Plus, Trash2, ImagePlus, X, GripVertical } from "lucide-react";
import { useStore } from "../store";
import { fileToDataUrl, productStock, uid } from "../utils/helpers";
import type { Gender, Product, ProductStatus, Translation } from "../types";

export default function AdminProducts() {
  const s = useStore();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const list = useMemo(() => {
    return s.products.filter((p) => {
      const n = q.toLowerCase();
      const match =
        !q ||
        s.tr(p.name).toLowerCase().includes(n) ||
        p.sku.toLowerCase().includes(n) ||
        (s.brands.find((b) => b.id === p.brandId)?.name || "").toLowerCase().includes(n);
      return match && (!cat || p.categoryId === cat);
    });
  }, [s.products, q, cat, s.lang]);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-serif text-3xl">{s.t("admin.products")}</h1>
        <Link to="/admin/products/new" className="flex items-center gap-2 bg-ink px-4 py-2 text-[11px] tracking-widest text-white">
          <Plus className="h-4 w-4" /> {s.t("prod.add").toUpperCase()}
        </Link>
      </div>
      <div className="mt-6 flex flex-wrap gap-3">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={s.t("common.search")} className="border border-black/15 bg-white px-3 py-2 text-sm" />
        <select value={cat} onChange={(e) => setCat(e.target.value)} className="border border-black/15 bg-white px-3 py-2 text-sm">
          <option value="">{s.t("prod.category")}</option>
          {s.categories.filter((c) => !c.parentId).map((c) => (
            <option key={c.id} value={c.id}>{s.tr(c.name)}</option>
          ))}
        </select>
      </div>
      <div className="mt-4 overflow-x-auto border border-black/10 bg-white">
        <table className="w-full min-w-[800px] text-sm">
          <thead className="bg-[#f6f1e8] text-[10px] uppercase tracking-widest text-mute">
            <tr>
              <th className="p-3 text-start">{s.t("prod.photos")}</th>
              <th className="p-3 text-start">{s.t("prod.name")}</th>
              <th className="p-3 text-start">SKU</th>
              <th className="p-3 text-start">{s.t("common.price")}</th>
              <th className="p-3 text-start">{s.t("common.stock")}</th>
              <th className="p-3 text-start">{s.t("common.status")}</th>
              <th className="p-3">{s.t("common.actions")}</th>
            </tr>
          </thead>
          <tbody>
            {list.map((p) => (
              <tr key={p.id} className="border-t border-black/5">
                <td className="p-2">
                  <img src={p.images[0]} alt="" className="h-14 w-11 object-cover" />
                </td>
                <td className="p-3">
                  <p className="font-medium">{s.tr(p.name)}</p>
                  <p className="text-xs text-mute">{s.brands.find((b) => b.id === p.brandId)?.name}</p>
                </td>
                <td className="p-3 text-xs">{p.sku}</td>
                <td className="p-3">{s.formatPrice(p.promoPrice || p.salePrice)}</td>
                <td className="p-3">{productStock(p)}</td>
                <td className="p-3">
                  <span className={`text-[10px] uppercase tracking-widest ${p.status === "available" ? "text-green-800" : p.status === "hidden" ? "text-mute" : "text-[#8b2e2e]"}`}>
                    {s.t(p.status === "available" ? "common.available" : p.status === "hidden" ? "common.hidden" : "common.outOfStock")}
                  </span>
                </td>
                <td className="p-3">
                  <div className="flex justify-end gap-1">
                    <Link to={`/admin/products/${p.id}`} className="p-1 hover:bg-[#f6f1e8]"><Pencil className="h-4 w-4" /></Link>
                    <button onClick={() => s.duplicateProduct(p.id)} className="p-1 hover:bg-[#f6f1e8]"><Copy className="h-4 w-4" /></button>
                    <button onClick={() => s.hideProduct(p.id, p.status !== "hidden")} className="p-1 hover:bg-[#f6f1e8]"><EyeOff className="h-4 w-4" /></button>
                    <button
                      onClick={() => {
                        if (confirm(s.t("prod.confirmDelete"))) s.deleteProduct(p.id);
                      }}
                      className="p-1 hover:bg-[#f6f1e8]"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const emptyT = (): Translation => ({ fr: "", ar: "", en: "" });

export function ProductForm() {
  const s = useStore();
  const { id } = useParams();
  const nav = useNavigate();
  const existing = id && id !== "new" ? s.products.find((p) => p.id === id) : undefined;
  const [p, setP] = useState<Product>(() =>
    existing
      ? JSON.parse(JSON.stringify(existing))
      : {
          id: uid("p"),
          name: emptyT(),
          description: emptyT(),
          images: [],
          categoryId: s.categories[0]?.id || "",
          brandId: s.brands[0]?.id || "",
          sku: "VEL-NEW",
          purchasePrice: 0,
          salePrice: 0,
          tags: [],
          status: "available",
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          gender: "unisexe",
          sizes: ["S", "M", "L"],
          colors: [{ name: "Noir", hex: "#111111" }],
          variants: [],
        }
  );
  const [sizeInput, setSizeInput] = useState(p.sizes.join(", "));
  const [colorInput, setColorInput] = useState(p.colors.map((c) => `${c.name}:${c.hex}`).join(", "));
  const [ok, setOk] = useState("");
  const [dragOver, setDragOver] = useState(false);

  const set = <K extends keyof Product>(k: K, v: Product[K]) => setP((prev) => ({ ...prev, [k]: v }));
  const setT = (field: "name" | "description" | "material", lang: keyof Translation, v: string) =>
    setP((prev) => ({ ...prev, [field]: { ...(prev[field] || emptyT()), [lang]: v } }));

  const addFiles = async (files: FileList | File[]) => {
    const arr = Array.from(files).filter((f) => f.type.startsWith("image/"));
    const urls: string[] = [];
    for (const f of arr) {
      try {
        urls.push(await fileToDataUrl(f));
      } catch {
        /* skip */
      }
    }
    if (urls.length) setP((prev) => ({ ...prev, images: [...prev.images, ...urls] }));
  };

  const addUrl = () => {
    const url = prompt("URL image");
    if (url) setP((prev) => ({ ...prev, images: [...prev.images, url] }));
  };

  const moveImg = (i: number, dir: number) => {
    const next = [...p.images];
    const j = i + dir;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    set("images", next);
  };

  const generate = () => {
    const sizes = sizeInput.split(",").map((x) => x.trim()).filter(Boolean);
    const colors = colorInput.split(",").map((x) => {
      const [name, hex] = x.split(":").map((t) => t.trim());
      return { name, hex: hex || "#cccccc" };
    }).filter((c) => c.name);
    const variants: Product["variants"] = [];
    for (const c of colors) {
      for (const sz of sizes) {
        const prev = p.variants.find((v) => v.size === sz && v.color === c.name);
        variants.push({
          id: prev?.id || uid("v"),
          productId: p.id,
          size: sz,
          color: c.name,
          colorHex: c.hex,
          sku: `${p.sku}-${c.name.slice(0, 2).toUpperCase()}-${sz}`,
          stock: prev?.stock ?? 10,
          minStock: prev?.minStock ?? 5,
        });
      }
    }
    setP((prev) => ({ ...prev, sizes, colors, variants }));
    return { sizes, colors, variants };
  };

  const save = () => {
    if (!p.name.fr || !p.sku) {
      alert(s.t("common.required"));
      return;
    }
    let next = { ...p };
    if (next.variants.length === 0) {
      const g = generate();
      next = { ...next, ...g };
    }
    next = { ...next, updatedAt: new Date().toISOString() };
    const total = next.variants.reduce((n, v) => n + v.stock, 0);
    if (total === 0 && next.status === "available") next.status = "out_of_stock";
    s.saveProduct(next);
    setOk(s.t("prod.saved"));
    setTimeout(() => nav("/admin/products"), 600);
  };

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-serif text-3xl">{existing ? s.t("prod.edit") : s.t("prod.add")}</h1>

      <section className="mt-8 border border-black/10 bg-white p-5">
        <p className="text-[11px] uppercase tracking-widest">{s.t("prod.photos")}</p>
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
          }}
          className={`mt-3 border-2 border-dashed p-6 text-center ${dragOver ? "border-ink bg-[#f6f1e8]" : "border-black/15"}`}
        >
          <ImagePlus className="mx-auto h-8 w-8 text-mute" />
          <p className="mt-2 text-sm text-mute">{s.t("prod.drop")}</p>
          <div className="mt-3 flex justify-center gap-2">
            <label className="cursor-pointer bg-ink px-4 py-2 text-[11px] tracking-widest text-white">
              {s.t("prod.addPhotos").toUpperCase()}
              <input
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => {
                  if (e.target.files) addFiles(e.target.files);
                  e.target.value = "";
                }}
              />
            </label>
            <button type="button" onClick={addUrl} className="border border-black/15 px-4 py-2 text-[11px] tracking-widest">
              URL
            </button>
          </div>
        </div>
        {p.images.length > 0 && (
          <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-5">
            {p.images.map((src, i) => (
              <div key={i} className="group relative">
                <img src={src} alt="" className="aspect-[3/4] w-full object-cover" />
                <div className="absolute inset-0 flex items-start justify-between bg-black/0 p-1 opacity-0 transition group-hover:bg-black/30 group-hover:opacity-100">
                  <button type="button" onClick={() => moveImg(i, -1)} className="bg-white p-1"><GripVertical className="h-3 w-3" /></button>
                  <button type="button" onClick={() => set("images", p.images.filter((_, j) => j !== i))} className="bg-white p-1"><X className="h-3 w-3" /></button>
                </div>
                <div className="mt-1 flex gap-1">
                  <button type="button" className="text-[10px] underline" onClick={() => moveImg(i, -1)}>←</button>
                  <button type="button" className="text-[10px] underline" onClick={() => moveImg(i, 1)}>→</button>
                </div>
              </div>
            ))}
          </div>
        )}
        <label className="mt-4 block text-xs">
          <span className="text-mute">{s.t("prod.video")}</span>
          <input value={p.video || ""} onChange={(e) => set("video", e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2" />
        </label>
      </section>

      <section className="mt-4 grid gap-4 border border-black/10 bg-white p-5 md:grid-cols-3">
        {(["fr", "ar", "en"] as const).map((lang) => (
          <label key={lang} className="text-xs">
            {s.t("prod.name")} ({lang})
            <input value={p.name[lang]} onChange={(e) => setT("name", lang, e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2" dir={lang === "ar" ? "rtl" : "ltr"} />
          </label>
        ))}
        {(["fr", "ar", "en"] as const).map((lang) => (
          <label key={"d" + lang} className="text-xs md:col-span-1">
            {s.t("prod.desc")} ({lang})
            <textarea value={p.description[lang]} onChange={(e) => setT("description", lang, e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2" rows={3} dir={lang === "ar" ? "rtl" : "ltr"} />
          </label>
        ))}
        {(["fr", "ar", "en"] as const).map((lang) => (
          <label key={"m" + lang} className="text-xs">
            {s.t("common.material")} ({lang})
            <input value={p.material?.[lang] || ""} onChange={(e) => setT("material", lang, e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2" dir={lang === "ar" ? "rtl" : "ltr"} />
          </label>
        ))}
      </section>

      <section className="mt-4 grid gap-4 border border-black/10 bg-white p-5 sm:grid-cols-3">
        <label className="text-xs">{s.t("common.sku")}<input value={p.sku} onChange={(e) => set("sku", e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("prod.category")}
          <select value={p.categoryId} onChange={(e) => set("categoryId", e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2">
            {s.categories.filter((c) => !c.parentId).map((c) => <option key={c.id} value={c.id}>{s.tr(c.name)}</option>)}
          </select>
        </label>
        <label className="text-xs">{s.t("prod.subcat")}
          <select value={p.subcategoryId || ""} onChange={(e) => set("subcategoryId", e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2">
            <option value="">—</option>
            {s.categories.filter((c) => c.parentId === p.categoryId).map((c) => <option key={c.id} value={c.id}>{s.tr(c.name)}</option>)}
          </select>
        </label>
        <label className="text-xs">{s.t("common.brand")}
          <select value={p.brandId} onChange={(e) => set("brandId", e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2">
            {s.brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </label>
        <label className="text-xs">{s.t("product.gender")}
          <select value={p.gender} onChange={(e) => set("gender", e.target.value as Gender)} className="mt-1 w-full border border-black/15 px-3 py-2">
            {["homme", "femme", "enfant", "unisexe"].map((g) => <option key={g} value={g}>{g}</option>)}
          </select>
        </label>
        <label className="text-xs">{s.t("common.status")}
          <select value={p.status} onChange={(e) => set("status", e.target.value as ProductStatus)} className="mt-1 w-full border border-black/15 px-3 py-2">
            <option value="available">{s.t("common.available")}</option>
            <option value="out_of_stock">{s.t("common.outOfStock")}</option>
            <option value="hidden">{s.t("common.hidden")}</option>
          </select>
        </label>
        <label className="text-xs">{s.t("prod.purchase")}<input type="number" value={p.purchasePrice} onChange={(e) => set("purchasePrice", Number(e.target.value))} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("prod.sale")}<input type="number" value={p.salePrice} onChange={(e) => set("salePrice", Number(e.target.value))} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("prod.old")}<input type="number" value={p.oldPrice || ""} onChange={(e) => set("oldPrice", Number(e.target.value) || undefined)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("prod.promo")}<input type="number" value={p.promoPrice || ""} onChange={(e) => set("promoPrice", Number(e.target.value) || undefined)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("prod.percent")}<input type="number" value={p.promoPercent || ""} onChange={(e) => set("promoPercent", Number(e.target.value) || undefined)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("prod.promoStart")}<input type="datetime-local" value={p.promoStart?.slice(0, 16) || ""} onChange={(e) => set("promoStart", e.target.value ? new Date(e.target.value).toISOString() : undefined)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("prod.promoEnd")}<input type="datetime-local" value={p.promoEnd?.slice(0, 16) || ""} onChange={(e) => set("promoEnd", e.target.value ? new Date(e.target.value).toISOString() : undefined)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("product.age")}<input value={p.ageRange || ""} onChange={(e) => set("ageRange", e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("product.weight")}<input type="number" value={p.weight || ""} onChange={(e) => set("weight", Number(e.target.value) || undefined)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs">{s.t("product.dimensions")}<input value={p.dimensions || ""} onChange={(e) => set("dimensions", e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="text-xs sm:col-span-3">{s.t("prod.tags")}<input value={p.tags.join(", ")} onChange={(e) => set("tags", e.target.value.split(",").map((t) => t.trim()).filter(Boolean))} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!p.featured} onChange={(e) => set("featured", e.target.checked)} /> {s.t("prod.featured")}</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!p.isNew} onChange={(e) => set("isNew", e.target.checked)} /> {s.t("prod.new")}</label>
      </section>

      <section className="mt-4 border border-black/10 bg-white p-5">
        <p className="text-[11px] uppercase tracking-widest">{s.t("prod.variants")}</p>
        <p className="mt-1 text-xs text-mute">Tailles: S, M, L · Couleurs: Noir:#111111, Blanc:#f5f1ea</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <label className="text-xs">{s.t("common.size")}<input value={sizeInput} onChange={(e) => setSizeInput(e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
          <label className="text-xs">{s.t("common.color")}<input value={colorInput} onChange={(e) => setColorInput(e.target.value)} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
        </div>
        <button type="button" onClick={generate} className="mt-3 border border-black/15 px-4 py-2 text-[11px] tracking-widest">
          {s.t("prod.generate").toUpperCase()}
        </button>
        {p.variants.length > 0 && (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[10px] uppercase tracking-widest text-mute">
                <tr>
                  <th className="p-2 text-start">{s.t("common.color")}</th>
                  <th className="p-2 text-start">{s.t("common.size")}</th>
                  <th className="p-2 text-start">SKU</th>
                  <th className="p-2 text-start">{s.t("common.stock")}</th>
                  <th className="p-2 text-start">{s.t("prod.minStock")}</th>
                </tr>
              </thead>
              <tbody>
                {p.variants.map((v, i) => (
                  <tr key={v.id} className="border-t border-black/5">
                    <td className="p-2">{v.color}</td>
                    <td className="p-2">{v.size}</td>
                    <td className="p-2 text-xs">{v.sku}</td>
                    <td className="p-2">
                      <input type="number" value={v.stock} onChange={(e) => {
                        const variants = p.variants.map((x, j) => j === i ? { ...x, stock: Number(e.target.value) } : x);
                        set("variants", variants);
                      }} className="w-20 border border-black/15 px-2 py-1" />
                    </td>
                    <td className="p-2">
                      <input type="number" value={v.minStock} onChange={(e) => {
                        const variants = p.variants.map((x, j) => j === i ? { ...x, minStock: Number(e.target.value) } : x);
                        set("variants", variants);
                      }} className="w-20 border border-black/15 px-2 py-1" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {ok && <p className="mt-4 text-green-800">{ok}</p>}
      <div className="mt-6 flex gap-3">
        <button onClick={save} className="bg-ink px-6 py-3 text-[11px] tracking-widest text-white">{s.t("common.save").toUpperCase()}</button>
        <button onClick={() => nav("/admin/products")} className="border border-black/15 px-6 py-3 text-[11px] tracking-widest">{s.t("common.cancel").toUpperCase()}</button>
      </div>
    </div>
  );
}
