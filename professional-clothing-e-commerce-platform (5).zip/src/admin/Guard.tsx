import { useLocation } from "react-router-dom";
import { useStore } from "../store";
import type { Permission } from "../types";

const MAP: Record<string, Permission> = {
  "/admin": "dashboard",
  "/admin/products": "products",
  "/admin/inventory": "stock",
  "/admin/prices": "prices",
  "/admin/orders": "orders",
  "/admin/customers": "customers",
  "/admin/reports": "reports",
  "/admin/settings": "settings",
  "/admin/users": "users",
  "/admin/activity": "activity",
};

export function AdminGuard({ children }: { children: React.ReactNode }) {
  const s = useStore();
  const loc = useLocation();
  const path = loc.pathname.replace(/\/$/, "") || "/admin";
  let perm: Permission = "dashboard";
  for (const [p, pe] of Object.entries(MAP)) {
    if (path === p || path.startsWith(p + "/")) perm = pe;
  }
  if (path.startsWith("/admin/products")) perm = "products";
  if (!s.hasPermission(perm)) {
    return (
      <div className="py-20 text-center">
        <p className="font-serif text-2xl">Accès refusé</p>
        <p className="mt-2 text-sm text-mute">Access denied · غير مسموح</p>
      </div>
    );
  }
  return <>{children}</>;
}
