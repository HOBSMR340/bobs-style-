import { useState } from "react";
import { useStore } from "../store";
import { ALL_PERMISSIONS, ROLE_PERMISSIONS, type AdminUser, type Lang, type Permission, type Role, type Settings } from "../types";
import { formatDate, uid } from "../utils/helpers";
import { LANG_META } from "../i18n";

export function AdminSettings() {
  const s = useStore();
  const [tab, setTab] = useState("general");
  const [st, setSt] = useState<Settings>({ ...s.settings });
  const tabs = ["general", "appearance", "langs", "currencies", "shipping", "payment", "taxes", "notif"] as const;
  const labels: Record<string, string> = {
    general: s.t("set.general"),
    appearance: s.t("set.appearance"),
    langs: s.t("set.langs"),
    currencies: s.t("set.currencies"),
    shipping: s.t("set.shipping"),
    payment: s.t("set.payment"),
    taxes: s.t("set.taxes"),
    notif: s.t("set.notif"),
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-serif text-3xl">{s.t("admin.settings")}</h1>
        <button
          onClick={() => s.saveSettings(st)}
          className="bg-ink px-5 py-2 text-[11px] tracking-widest text-white"
        >
          {s.t("common.save").toUpperCase()}
        </button>
      </div>
      <div className="mt-6 flex flex-wrap gap-2">
        {tabs.map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-3 py-1 text-[11px] uppercase tracking-widest ${tab === t ? "bg-ink text-white" : "border border-black/15"}`}>
            {labels[t]}
          </button>
        ))}
      </div>
      <div className="mt-6 border border-black/10 bg-white p-6">
        {tab === "general" && (
          <div className="grid gap-4 sm:grid-cols-2">
            {(["fr", "ar", "en"] as const).map((l) => (
              <label key={l} className="text-xs">
                {s.t("set.storeName")} ({l})
                <input value={st.storeName[l]} onChange={(e) => setSt({ ...st, storeName: { ...st.storeName, [l]: e.target.value } })} className="mt-1 w-full border border-black/15 px-3 py-2" />
              </label>
            ))}
            <label className="text-xs">{s.t("checkout.email")}<input value={st.email} onChange={(e) => setSt({ ...st, email: e.target.value })} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
            <label className="text-xs">{s.t("checkout.phone")}<input value={st.phone} onChange={(e) => setSt({ ...st, phone: e.target.value })} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
            <label className="text-xs sm:col-span-2">{s.t("checkout.address")}<input value={st.address} onChange={(e) => setSt({ ...st, address: e.target.value })} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
            <label className="text-xs">Instagram<input value={st.social.instagram} onChange={(e) => setSt({ ...st, social: { ...st.social, instagram: e.target.value } })} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
            <label className="text-xs">Facebook<input value={st.social.facebook} onChange={(e) => setSt({ ...st, social: { ...st.social, facebook: e.target.value } })} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
          </div>
        )}
        {tab === "appearance" && (
          <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="text-xs">{s.lang === "ar" ? "اللون الرئيسي" : s.lang === "en" ? "Primary color" : "Couleur principale"}
                <div className="mt-1 flex items-center gap-2">
                  <input type="color" value={st.colors.primary} onChange={(e) => setSt({ ...st, colors: { ...st.colors, primary: e.target.value } })} className="h-10 w-12 border border-black/15" />
                  <input value={st.colors.primary} onChange={(e) => setSt({ ...st, colors: { ...st.colors, primary: e.target.value } })} className="w-full border border-black/15 px-3 py-2" />
                </div>
              </label>
              <label className="text-xs">{s.lang === "ar" ? "لون التمييز" : s.lang === "en" ? "Accent color" : "Couleur d'accent"}
                <div className="mt-1 flex items-center gap-2">
                  <input type="color" value={st.colors.accent} onChange={(e) => setSt({ ...st, colors: { ...st.colors, accent: e.target.value } })} className="h-10 w-12 border border-black/15" />
                  <input value={st.colors.accent} onChange={(e) => setSt({ ...st, colors: { ...st.colors, accent: e.target.value } })} className="w-full border border-black/15 px-3 py-2" />
                </div>
              </label>
              <label className="text-xs">{s.lang === "ar" ? "البانر العلوي (URL)" : s.lang === "en" ? "Top banner (URL)" : "Bannière haute (URL)"}
                <input value={st.banner} onChange={(e) => setSt({ ...st, banner: e.target.value })} className="mt-1 w-full border border-black/15 px-3 py-2" />
              </label>
              {(["fr", "ar", "en"] as const).map((l) => (
                <label key={"b" + l} className="text-xs">Banner text ({l})
                  <input value={st.bannerText[l]} onChange={(e) => setSt({ ...st, bannerText: { ...st.bannerText, [l]: e.target.value } })} className="mt-1 w-full border border-black/15 px-3 py-2" dir={l === "ar" ? "rtl" : "ltr"} />
                </label>
              ))}
              <label className="text-xs">{s.lang === "ar" ? "الخط" : s.lang === "en" ? "Typography" : "Typographie"}
                <select value={st.font} onChange={(e) => setSt({ ...st, font: e.target.value })} className="mt-1 w-full border border-black/15 px-3 py-2">
                  <option value="Cormorant">Cormorant Garamond (sérif)</option>
                  <option value="Outfit">Outfit (sans-serif)</option>
                </select>
              </label>
              <label className="text-xs">{s.lang === "ar" ? "شكل الأزرار" : s.lang === "en" ? "Buttons" : "Boutons"}
                <select value={st.buttonStyle} onChange={(e) => setSt({ ...st, buttonStyle: e.target.value as Settings["buttonStyle"] })} className="mt-1 w-full border border-black/15 px-3 py-2">
                  <option value="rounded">{s.lang === "ar" ? "مستديرة" : s.lang === "en" ? "Rounded" : "Arrondis"}</option>
                  <option value="square">{s.lang === "ar" ? "حادة" : s.lang === "en" ? "Square" : "Carrés"}</option>
                  <option value="pill">{s.lang === "ar" ? "كبسولة" : s.lang === "en" ? "Pill" : "Pilule"}</option>
                </select>
              </label>
              <label className="flex items-center gap-2 text-sm sm:col-span-2">
                <input type="checkbox" checked={st.darkMode} onChange={(e) => setSt({ ...st, darkMode: e.target.checked })} /> {s.t("set.dark")}
              </label>
            </div>
            <aside className="border border-black/10 bg-[#faf7f2] p-4">
              <p className="text-[10px] uppercase tracking-widest text-mute">Preview</p>
              <div className="mt-2 border border-black/10 bg-white p-4">
                <p className="text-[10px]" style={{ color: st.colors.accent }}>{st.bannerText[s.lang]}</p>
                <p className="mt-3 text-center font-serif text-2xl tracking-[0.3em]" style={{ color: st.colors.primary }}>{st.storeName[s.lang]}</p>
                <button className={`mt-4 w-full py-2 text-[10px] tracking-widest text-white ${st.buttonStyle === "rounded" ? "rounded-md" : st.buttonStyle === "pill" ? "rounded-full" : ""}`} style={{ background: st.colors.primary }}>
                  {s.t("common.save").toUpperCase()}
                </button>
              </div>
            </aside>
          </div>
        )}
        {tab === "langs" && (
          <div className="space-y-3">
            {(["fr", "ar", "en"] as Lang[]).map((l) => (
              <label key={l} className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={st.enabledLangs.includes(l)}
                  onChange={(e) => {
                    const enabledLangs = e.target.checked ? [...st.enabledLangs, l] : st.enabledLangs.filter((x) => x !== l);
                    setSt({ ...st, enabledLangs });
                  }}
                />
                {LANG_META[l].label} {l === "ar" && "(RTL)"}
              </label>
            ))}
          </div>
        )}
        {tab === "currencies" && (
          <div className="space-y-4">
            <p className="text-[11px] uppercase tracking-widest">Taux de change</p>
            <div className="grid gap-3 sm:grid-cols-3">
              {(["DZD", "EUR", "USD"] as const).map((c) => (
                <label key={c} className="text-xs">
                  {c} rate
                  <input type="number" step="0.0001" value={st.currencies[c].rate} onChange={(e) => setSt({ ...st, currencies: { ...st.currencies, [c]: { ...st.currencies[c], rate: Number(e.target.value) } } })} className="mt-1 w-full border border-black/15 px-3 py-2" />
                </label>
              ))}
            </div>
            <p className="text-[11px] uppercase tracking-widest">{s.lang === "ar" ? "العملة الافتراضية" : s.lang === "en" ? "Default currency" : "Devise par défaut"}</p>
            <select value={st.defaultCurrency} onChange={(e) => setSt({ ...st, defaultCurrency: e.target.value as Settings["defaultCurrency"] })} className="border border-black/15 bg-transparent px-3 py-2 text-sm">
              {(["DZD", "EUR", "USD"] as const).map((c) => <option key={c} value={c}>{c} ({st.currencies[c].symbol})</option>)}
            </select>
          </div>
        )}
        {tab === "shipping" && (
          <div className="space-y-4">
            <label className="text-xs block">{s.t("common.shipping")}<input type="number" value={st.shippingFee} onChange={(e) => setSt({ ...st, shippingFee: Number(e.target.value) })} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
            <label className="text-xs block">{s.t("set.freeFrom")}<input type="number" value={st.freeShippingFrom} onChange={(e) => setSt({ ...st, freeShippingFrom: Number(e.target.value) })} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr><th className="text-start p-2">Wilaya</th><th className="text-start p-2">Frais</th><th className="text-start p-2">Délai</th></tr></thead>
                <tbody>
                  {st.zones.map((z, i) => (
                    <tr key={z.wilaya} className="border-t">
                      <td className="p-2">{z.wilaya}</td>
                      <td className="p-2"><input type="number" value={z.fee} onChange={(e) => {
                        const zones = st.zones.map((x, j) => j === i ? { ...x, fee: Number(e.target.value) } : x);
                        setSt({ ...st, zones });
                      }} className="w-24 border px-2 py-1" /></td>
                      <td className="p-2">{z.delay}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        {tab === "payment" && (
          <div className="space-y-2">
            {(["cod", "card", "online", "other"] as const).map((k) => (
              <label key={k} className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={st.payments[k]} onChange={(e) => setSt({ ...st, payments: { ...st.payments, [k]: e.target.checked } })} />
                {k === "cod" ? s.t("checkout.cod") : k === "card" ? s.t("checkout.card") : k === "online" ? s.t("checkout.online") : "Autre"}
              </label>
            ))}
          </div>
        )}
        {tab === "taxes" && (
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={st.taxEnabled} onChange={(e) => setSt({ ...st, taxEnabled: e.target.checked })} /> TVA</label>
            <label className="text-xs block">{s.t("set.taxRate")}<input type="number" value={st.taxRate} onChange={(e) => setSt({ ...st, taxRate: Number(e.target.value) })} className="mt-1 w-full border border-black/15 px-3 py-2" /></label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={st.pricesIncludeTax} onChange={(e) => setSt({ ...st, pricesIncludeTax: e.target.checked })} /> {s.t("set.ttc")}</label>
          </div>
        )}
        {tab === "notif" && (
          <div className="space-y-2">
            {(Object.keys(st.notifications) as (keyof Settings["notifications"])[]).map((k) => (
              <label key={k} className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={st.notifications[k]} onChange={(e) => setSt({ ...st, notifications: { ...st.notifications, [k]: e.target.checked } })} />
                {k}
              </label>
            ))}
          </div>
        )}
      </div>
      <button onClick={() => { if (confirm("Reset demo data?")) s.resetDemo(); }} className="mt-6 text-xs text-mute underline">
        Reset demo
      </button>
      <p className="mt-2 text-[11px] text-mute">
        {s.lang === "ar" ? "تتوفر معاينة حية للاسم والشعار في صفحة المتجر." : s.lang === "en" ? "Live preview available for name and branding on the storefront." : "Aperçu en direct disponible sur la boutique."}
      </p>
    </div>
  );
}

export function AdminUsers() {
  const s = useStore();
  const [edit, setEdit] = useState<AdminUser | null>(null);
  const blank = (): AdminUser => ({
    id: uid("u"),
    email: "",
    password: "changeme",
    name: "",
    role: "seller",
    permissions: [...ROLE_PERMISSIONS.seller],
    active: true,
    createdAt: new Date().toISOString(),
  });
  return (
    <div>
      <div className="flex justify-between">
        <h1 className="font-serif text-3xl">{s.t("admin.users")}</h1>
        <button onClick={() => setEdit(blank())} className="bg-ink px-4 py-2 text-[11px] tracking-widest text-white">{s.t("common.add").toUpperCase()}</button>
      </div>
      <div className="mt-4 overflow-x-auto border border-black/10 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-[#f6f1e8] text-[10px] uppercase tracking-widest text-mute">
            <tr><th className="p-3 text-start">Nom</th><th className="p-3 text-start">Email</th><th className="p-3 text-start">Rôle</th><th></th></tr>
          </thead>
          <tbody>
            {s.users.map((u) => (
              <tr key={u.id} className="border-t">
                <td className="p-3">{u.name}</td>
                <td className="p-3">{u.email}</td>
                <td className="p-3">{s.t(`role.${u.role}`)}</td>
                <td className="p-3 text-end">
                  <button className="text-xs underline" onClick={() => setEdit({ ...u })}>{s.t("common.edit")}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {edit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setEdit(null)}>
          <div className="w-full max-w-md bg-white p-6" onClick={(e) => e.stopPropagation()}>
            <input className="mb-2 w-full border px-3 py-2" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} placeholder="Nom" />
            <input className="mb-2 w-full border px-3 py-2" value={edit.email} onChange={(e) => setEdit({ ...edit, email: e.target.value })} placeholder="Email" />
            <input className="mb-2 w-full border px-3 py-2" value={edit.password} onChange={(e) => setEdit({ ...edit, password: e.target.value })} placeholder="Password" />
            <select className="mb-3 w-full border px-3 py-2" value={edit.role} onChange={(e) => {
              const role = e.target.value as Role;
              setEdit({ ...edit, role, permissions: [...ROLE_PERMISSIONS[role]] });
            }}>
              {(["super_admin", "manager", "seller", "stock_manager"] as Role[]).map((r) => <option key={r} value={r}>{s.t(`role.${r}`)}</option>)}
            </select>
            <div className="max-h-40 space-y-1 overflow-auto text-sm">
              {ALL_PERMISSIONS.map((p) => (
                <label key={p} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={edit.permissions.includes(p)}
                    onChange={(e) => {
                      const permissions = e.target.checked
                        ? ([...edit.permissions, p] as Permission[])
                        : (edit.permissions.filter((x) => x !== p) as Permission[]);
                      setEdit({ ...edit, permissions });
                    }}
                  />
                  {p}
                </label>
              ))}
            </div>
            <div className="mt-4 flex gap-2">
              <button className="bg-ink px-4 py-2 text-white text-xs" onClick={() => { s.saveUser(edit); setEdit(null); }}>{s.t("common.save")}</button>
              {s.users.some((u) => u.id === edit.id) && edit.id !== "u-admin" && (
                <button className="text-xs text-[#8b2e2e]" onClick={() => { s.deleteUser(edit.id); setEdit(null); }}>{s.t("common.delete")}</button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function AdminActivity() {
  const s = useStore();
  return (
    <div>
      <h1 className="font-serif text-3xl">{s.t("admin.activity")}</h1>
      <ul className="mt-6 divide-y border border-black/10 bg-white">
        {s.activity.map((a) => (
          <li key={a.id} className="p-4 text-sm">
            <p className="font-medium">{a.userName} · {a.action} · {a.entity}</p>
            <p className="text-mute">{a.details}</p>
            <p className="text-xs text-mute">{formatDate(a.createdAt, s.lang)}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
