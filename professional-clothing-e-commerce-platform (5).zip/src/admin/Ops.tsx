import { useMemo, useState } from "react";
import { useStore } from "../store";
import { formatDate, productStock } from "../utils/helpers";
import type { MovementType, OrderStatus } from "../types";

const STATUSES: OrderStatus[] = ["new", "confirmed", "preparing", "shipped", "delivered", "cancelled", "returned"];

export function AdminOrders() {
  const s = useStore();
  const [q, setQ] = useState("");
  const [st, setSt] = useState<"" | OrderStatus>("");
  const [open, setOpen] = useState<string | null>(null);
  const list = s.orders.filter((o) => {
    const n = q.toLowerCase();
    const match =
      !q ||
      o.number.toLowerCase().includes(n) ||
      o.shippingAddress.lastName.toLowerCase().includes(n) ||
      o.shippingAddress.phone.includes(q);
    return match && (!st || o.status === st);
  });
  const sel = s.orders.find((o) => o.id === open);

  return (
    <div>
      <h1 className="font-serif text-3xl">{s.t("admin.orders")}</h1>
      <div className="mt-4 flex flex-wrap gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={s.t("common.search")} className="border border-black/15 bg-white px-3 py-2 text-sm" />
        <select value={st} onChange={(e) => setSt(e.target.value as typeof st)} className="border border-black/15 bg-white px-3 py-2 text-sm">
          <option value="">{s.t("common.status")}</option>
          {STATUSES.map((x) => (
            <option key={x} value={x}>{s.t(`order.${x}`)}</option>
          ))}
        </select>
      </div>
      <div className="mt-4 overflow-x-auto border border-black/10 bg-white">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="bg-[#f6f1e8] text-[10px] uppercase tracking-widest text-mute">
            <tr>
              <th className="p-3 text-start">#</th>
              <th className="p-3 text-start">{s.t("checkout.info")}</th>
              <th className="p-3 text-start">{s.t("common.date")}</th>
              <th className="p-3 text-start">{s.t("common.status")}</th>
              <th className="p-3 text-start">{s.t("common.total")}</th>
            </tr>
          </thead>
          <tbody>
            {list.map((o) => (
              <tr key={o.id} className="cursor-pointer border-t border-black/5 hover:bg-[#faf7f2]" onClick={() => setOpen(o.id)}>
                <td className="p-3 font-medium">{o.number}</td>
                <td className="p-3">
                  {o.shippingAddress.firstName} {o.shippingAddress.lastName}
                  <p className="text-xs text-mute">{o.shippingAddress.wilaya}</p>
                </td>
                <td className="p-3 text-xs">{formatDate(o.createdAt, s.lang)}</td>
                <td className="p-3 text-xs">{s.t(`order.${o.status}`)}</td>
                <td className="p-3">{s.formatPrice(o.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {sel && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-4 md:items-center" onClick={() => setOpen(null)}>
          <div className="max-h-[90vh] w-full max-w-lg overflow-auto bg-white p-6" onClick={(e) => e.stopPropagation()}>
            <h2 className="font-serif text-2xl">{sel.number}</h2>
            <p className="text-xs text-mute">{formatDate(sel.createdAt, s.lang)}</p>
            <div className="mt-4 text-sm">
              <p>{sel.shippingAddress.firstName} {sel.shippingAddress.lastName}</p>
              <p>{sel.shippingAddress.phone} · {sel.shippingAddress.email}</p>
              <p>{sel.shippingAddress.address}, {sel.shippingAddress.city}, {sel.shippingAddress.wilaya}</p>
            </div>
            <div className="mt-4 divide-y">
              {sel.items.map((it) => (
                <div key={it.variantId} className="flex gap-3 py-2 text-sm">
                  <img src={it.image} className="h-14 w-11 object-cover" alt="" />
                  <div className="flex-1">
                    {s.tr(it.name)} · {it.color}/{it.size} × {it.quantity}
                  </div>
                  <span>{s.formatPrice(it.total)}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 font-medium">{s.t("common.total")}: {s.formatPrice(sel.total)}</p>
            <label className="mt-4 block text-xs">
              {s.t("common.status")}
              <select
                value={sel.status}
                onChange={(e) => s.updateOrderStatus(sel.id, e.target.value as OrderStatus)}
                className="mt-1 w-full border border-black/15 px-3 py-2"
              >
                {STATUSES.map((x) => <option key={x} value={x}>{s.t(`order.${x}`)}</option>)}
              </select>
            </label>
            <label className="mt-3 block text-xs">
              Notes internes
              <textarea
                defaultValue={sel.internalNotes}
                onBlur={(e) => s.updateOrderStatus(sel.id, sel.status, e.target.value)}
                className="mt-1 w-full border border-black/15 px-3 py-2"
                rows={3}
              />
            </label>
          </div>
        </div>
      )}
    </div>
  );
}

export function AdminCustomers() {
  const s = useStore();
  const [q, setQ] = useState("");
  const list = s.customers.filter((c) => {
    const n = q.toLowerCase();
    return !q || `${c.firstName} ${c.lastName}`.toLowerCase().includes(n) || c.email.toLowerCase().includes(n) || c.phone.includes(q);
  });
  return (
    <div>
      <h1 className="font-serif text-3xl">{s.t("admin.customers")}</h1>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={s.t("common.search")} className="mt-4 border border-black/15 bg-white px-3 py-2 text-sm" />
      <div className="mt-4 overflow-x-auto border border-black/10 bg-white">
        <table className="w-full min-w-[700px] text-sm">
          <thead className="bg-[#f6f1e8] text-[10px] uppercase tracking-widest text-mute">
            <tr>
              <th className="p-3 text-start">{s.t("checkout.lastName")}</th>
              <th className="p-3 text-start">{s.t("checkout.email")}</th>
              <th className="p-3 text-start">{s.t("checkout.phone")}</th>
              <th className="p-3 text-start">{s.t("checkout.wilaya")}</th>
              <th className="p-3 text-start">{s.t("cust.orders")}</th>
              <th className="p-3 text-start">{s.t("cust.spent")}</th>
            </tr>
          </thead>
          <tbody>
            {list.map((c) => {
              const ords = s.orders.filter((o) => o.customerId === c.id && o.status !== "cancelled");
              const spent = ords.reduce((n, o) => n + o.total, 0);
              return (
                <tr key={c.id} className="border-t border-black/5">
                  <td className="p-3">{c.firstName} {c.lastName}</td>
                  <td className="p-3 text-xs">{c.email}</td>
                  <td className="p-3 text-xs">{c.phone}</td>
                  <td className="p-3">{c.wilaya}</td>
                  <td className="p-3">{ords.length}</td>
                  <td className="p-3">{s.formatPrice(spent)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function AdminInventory() {
  const s = useStore();
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<string>("");
  const [type, setType] = useState<MovementType>("in");
  const [qty, setQty] = useState(1);
  const [note, setNote] = useState("");
  const rows = useMemo(() => {
    const n = q.toLowerCase();
    return s.products.flatMap((p) =>
      p.variants
        .filter((v) => !q || s.tr(p.name).toLowerCase().includes(n) || v.sku.toLowerCase().includes(n) || v.color.toLowerCase().includes(n) || v.size.toLowerCase().includes(n))
        .map((v) => ({ p, v }))
    );
  }, [s.products, q, s.lang]);

  return (
    <div>
      <h1 className="font-serif text-3xl">{s.t("admin.stock")}</h1>
      <div className="mt-4 flex flex-wrap gap-2 border border-black/10 bg-white p-4">
        <select value={sel} onChange={(e) => setSel(e.target.value)} className="border border-black/15 px-2 py-2 text-sm">
          <option value="">Variante</option>
          {rows.map(({ p, v }) => (
            <option key={v.id} value={v.id}>{s.tr(p.name)} · {v.color}/{v.size}</option>
          ))}
        </select>
        <select value={type} onChange={(e) => setType(e.target.value as MovementType)} className="border border-black/15 px-2 py-2 text-sm">
          <option value="in">{s.t("stock.in")}</option>
          <option value="out">{s.t("stock.out")}</option>
          <option value="adjust">{s.t("stock.adjust")}</option>
        </select>
        <input type="number" value={qty} onChange={(e) => setQty(Number(e.target.value))} className="w-24 border border-black/15 px-2 py-2 text-sm" />
        <input value={note} onChange={(e) => setNote(e.target.value)} placeholder={s.t("stock.note")} className="border border-black/15 px-2 py-2 text-sm" />
        <button
          onClick={() => {
            if (!sel) return;
            s.adjustStock(sel, type, qty, note);
            setNote("");
          }}
          className="bg-ink px-4 py-2 text-[11px] tracking-widest text-white"
        >
          {s.t("stock.apply").toUpperCase()}
        </button>
      </div>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={s.t("common.search")} className="mt-4 border border-black/15 bg-white px-3 py-2 text-sm" />
      <div className="mt-4 overflow-x-auto border border-black/10 bg-white">
        <table className="w-full min-w-[700px] text-sm">
          <thead className="bg-[#f6f1e8] text-[10px] uppercase tracking-widest text-mute">
            <tr>
              <th className="p-3 text-start">{s.t("prod.name")}</th>
              <th className="p-3 text-start">{s.t("common.color")}</th>
              <th className="p-3 text-start">{s.t("common.size")}</th>
              <th className="p-3 text-start">{s.t("common.stock")}</th>
              <th className="p-3 text-start">{s.t("prod.minStock")}</th>
              <th className="p-3 text-start">{s.t("common.status")}</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(({ p, v }) => {
              const alert = v.stock <= v.minStock;
              return (
                <tr key={v.id} className={`border-t border-black/5 ${alert ? "bg-red-50" : ""}`}>
                  <td className="p-3">{s.tr(p.name)}</td>
                  <td className="p-3">{v.color}</td>
                  <td className="p-3">{v.size}</td>
                  <td className="p-3">
                    <input
                      type="number"
                      defaultValue={v.stock}
                      key={v.stock}
                      onBlur={(e) => s.adjustStock(v.id, "adjust", Number(e.target.value), "Ajustement tableau")}
                      className="w-20 border border-black/10 px-2 py-1"
                    />
                  </td>
                  <td className="p-3">{v.minStock}</td>
                  <td className="p-3 text-xs">{v.stock === 0 ? s.t("common.outOfStock") : alert ? s.t("common.lowStock") : s.t("common.available")}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <h2 className="mt-8 text-[11px] uppercase tracking-widest">{s.t("stock.history")}</h2>
      <ul className="mt-2 max-h-64 overflow-auto border border-black/10 bg-white text-sm">
        {s.movements.slice(0, 40).map((m) => (
          <li key={m.id} className="border-b border-black/5 px-3 py-2">
            {formatDate(m.createdAt, s.lang)} · {m.type} · {m.quantity} · {m.previousStock}→{m.newStock} · {m.userName} {m.note && `· ${m.note}`}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function AdminPrices() {
  const s = useStore();
  const [sel, setSel] = useState<string[]>([]);
  const [pct, setPct] = useState(5);
  const toggle = (id: string) => setSel((x) => (x.includes(id) ? x.filter((i) => i !== id) : [...x, id]));
  return (
    <div>
      <h1 className="font-serif text-3xl">{s.t("admin.prices")}</h1>
      <div className="mt-4 flex flex-wrap items-center gap-2 border border-black/10 bg-white p-4">
        <span className="text-sm">{sel.length} {s.t("price.selected")}</span>
        <input type="number" value={pct} onChange={(e) => setPct(Number(e.target.value))} className="w-20 border border-black/15 px-2 py-1" />
        <span className="text-xs">%</span>
        <button onClick={() => s.bulkUpdatePrices(sel, pct)} className="bg-ink px-3 py-2 text-[11px] tracking-widest text-white">{s.t("price.increase").toUpperCase()}</button>
        <button onClick={() => s.bulkUpdatePrices(sel, -Math.abs(pct))} className="border border-black/15 px-3 py-2 text-[11px] tracking-widest">{s.t("price.decrease").toUpperCase()}</button>
        <button onClick={() => setSel(s.products.map((p) => p.id))} className="text-xs underline">{s.lang === "en" ? "Select all" : "Tout sélectionner"}</button>
      </div>
      <div className="mt-4 overflow-x-auto border border-black/10 bg-white">
        <table className="w-full min-w-[800px] text-sm">
          <thead className="bg-[#f6f1e8] text-[10px] uppercase tracking-widest text-mute">
            <tr>
              <th className="p-3"></th>
              <th className="p-3 text-start">{s.t("prod.name")}</th>
              <th className="p-3 text-start">{s.t("prod.purchase")}</th>
              <th className="p-3 text-start">{s.t("prod.sale")}</th>
              <th className="p-3 text-start">{s.t("prod.old")}</th>
              <th className="p-3 text-start">{s.t("prod.promo")}</th>
            </tr>
          </thead>
          <tbody>
            {s.products.map((p) => (
              <tr key={p.id} className="border-t border-black/5">
                <td className="p-3"><input type="checkbox" checked={sel.includes(p.id)} onChange={() => toggle(p.id)} /></td>
                <td className="p-3">{s.tr(p.name)}</td>
                <td className="p-3">
                  <input type="number" defaultValue={p.purchasePrice} className="w-24 border border-black/10 px-2 py-1" onBlur={(e) => s.saveProduct({ ...p, purchasePrice: Number(e.target.value) })} />
                </td>
                <td className="p-3">
                  <input type="number" defaultValue={p.salePrice} className="w-24 border border-black/10 px-2 py-1" onBlur={(e) => s.saveProduct({ ...p, salePrice: Number(e.target.value) })} />
                </td>
                <td className="p-3">
                  <input type="number" defaultValue={p.oldPrice || ""} className="w-24 border border-black/10 px-2 py-1" onBlur={(e) => s.saveProduct({ ...p, oldPrice: Number(e.target.value) || undefined })} />
                </td>
                <td className="p-3">
                  <input type="number" defaultValue={p.promoPrice || ""} className="w-24 border border-black/10 px-2 py-1" onBlur={(e) => s.saveProduct({ ...p, promoPrice: Number(e.target.value) || undefined })} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function AdminReports() {
  const s = useStore();
  const exportOrders = () => {
    const rows = [
      ["Number", "Date", "Customer", "Status", "Total"],
      ...s.orders.map((o) => [o.number, o.createdAt, `${o.shippingAddress.firstName} ${o.shippingAddress.lastName}`, o.status, o.total]),
    ];
    import("../utils/helpers").then((h) => h.exportCSV("velora-commandes.csv", rows));
  };
  const exportProducts = () => {
    const rows = [
      ["SKU", "Name", "Price", "Stock", "Status"],
      ...s.products.map((p) => [p.sku, p.name.fr, p.salePrice, productStock(p), p.status]),
    ];
    import("../utils/helpers").then((h) => h.exportCSV("velora-produits.csv", rows));
  };
  const exportStock = () => {
    const rows: (string | number)[][] = [["SKU", "Product", "Color", "Size", "Stock"]];
    s.products.forEach((p) => p.variants.forEach((v) => rows.push([v.sku, p.name.fr, v.color, v.size, v.stock])));
    import("../utils/helpers").then((h) => h.exportCSV("velora-stock.csv", rows));
  };
  const exportCustomers = () => {
    const rows = [["Name", "Email", "Phone", "Wilaya"], ...s.customers.map((c) => [`${c.firstName} ${c.lastName}`, c.email, c.phone, c.wilaya])];
    import("../utils/helpers").then((h) => h.exportCSV("velora-clients.csv", rows));
  };
  const pdf = (title: string, html: string) => import("../utils/helpers").then((h) => h.printPDF(title, html));

  const btns = [
    { l: s.t("admin.orders") + " CSV", fn: exportOrders },
    { l: s.t("admin.products") + " CSV", fn: exportProducts },
    { l: s.t("admin.stock") + " CSV", fn: exportStock },
    { l: s.t("admin.customers") + " CSV", fn: exportCustomers },
    {
      l: "PDF " + s.t("admin.orders"),
      fn: () =>
        pdf(
          "Commandes",
          `<h1>${s.tr(s.settings.storeName)} — ${s.t("admin.orders")}</h1><table><tr><th>#</th><th>Client</th><th>Total</th></tr>${s.orders
            .map((o) => `<tr><td>${o.number}</td><td>${o.shippingAddress.lastName}</td><td>${o.total}</td></tr>`)
            .join("")}</table>`
        ),
    },
  ];

  return (
    <div>
      <h1 className="font-serif text-3xl">{s.t("admin.reports")}</h1>
      <p className="mt-2 text-sm text-mute">CSV / Excel · PDF</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {btns.map((b) => (
          <button key={b.l} onClick={b.fn} className="border border-black/10 bg-white p-6 text-start hover:bg-[#f6f1e8]">
            <p className="text-[11px] uppercase tracking-widest">{s.t("common.export")}</p>
            <p className="mt-2 font-serif text-xl">{b.l}</p>
          </button>
        ))}
      </div>
    </div>
  );
}
