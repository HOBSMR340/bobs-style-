import { Link, useParams } from "react-router-dom";
import { useStore } from "../store";

export default function OrderSuccess() {
  const { id } = useParams();
  const s = useStore();
  const order = s.orders.find((o) => o.id === id);
  if (!order) {
    return (
      <div className="py-24 text-center">
        <p>{s.t("common.empty")}</p>
      </div>
    );
  }
  return (
    <div className="mx-auto max-w-2xl px-4 py-16 text-center">
      <p className="text-[11px] uppercase tracking-[0.3em] text-[#c4a574]">{s.t("checkout.success")}</p>
      <h1 className="mt-3 font-serif text-4xl">
        {s.t("checkout.orderNo")} {order.number}
      </h1>
      <p className="mt-4 text-mute">{s.t("checkout.successHint")}</p>
      <p className="mt-2 text-sm">
        {s.t(`order.${order.status}`)} · {s.formatPrice(order.total)}
      </p>
      <div className="mt-8 divide-y divide-black/10 border border-black/10 text-start">
        {order.items.map((it) => (
          <div key={it.variantId} className="flex items-center gap-3 p-3 text-sm">
            <img src={it.image} className="h-16 w-12 object-cover" alt="" />
            <div className="flex-1">
              <p>{s.tr(it.name)}</p>
              <p className="text-xs text-mute">
                {it.color} / {it.size} × {it.quantity}
              </p>
            </div>
            <span>{s.formatPrice(it.total)}</span>
          </div>
        ))}
      </div>
      <div className="mt-6 text-sm text-mute">
        {order.shippingAddress.firstName} {order.shippingAddress.lastName} · {order.shippingAddress.wilaya}
      </div>
      <Link to="/shop" className="mt-8 inline-block bg-ink px-8 py-3 text-[11px] tracking-[0.22em] text-white">
        {s.t("cart.continue").toUpperCase()}
      </Link>
    </div>
  );
}
