import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { useStore } from "../store";
import { ProductCard } from "../components/ProductCard";
import { HERO_IMG, BOUTIQUE_IMG } from "../seed";
import { isOnSale, productStock } from "../utils/helpers";

export default function Home() {
  const s = useStore();
  const visible = s.products.filter((p) => p.status !== "hidden");
  const popular = visible.filter((p) => p.featured).slice(0, 8);
  const news = [...visible].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)).slice(0, 8);
  const sales = visible.filter(isOnSale).slice(0, 8);
  const cats = s.categories.filter((c) => !c.parentId);
  const reco = visible.filter((p) => p.isNew || p.featured).slice(0, 4);

  const soldCount: Record<string, number> = {};
  s.orders.forEach((o) => {
    if (o.status === "cancelled") return;
    o.items.forEach((it) => {
      soldCount[it.productId] = (soldCount[it.productId] || 0) + it.quantity;
    });
  });
  const bestsellers = [...visible]
    .sort((a, b) => (soldCount[b.id] || 0) - (soldCount[a.id] || 0))
    .slice(0, 8);

  return (
    <div>
      <section className="relative min-h-[78vh] overflow-hidden bg-ink text-white">
        <img src={HERO_IMG} alt="" className="absolute inset-0 h-full w-full object-cover opacity-70" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
        <div className="relative mx-auto flex min-h-[78vh] max-w-7xl flex-col justify-center px-4 py-24 lg:px-8">
          <p className="fade-up text-[11px] uppercase tracking-[0.45em] text-[#c4a574]">{s.t("hero.kicker")}</p>
          <h1 className="fade-up mt-4 max-w-xl font-serif text-5xl leading-[1.05] sm:text-7xl">{s.t("hero.title")}</h1>
          <p className="fade-up mt-6 max-w-md text-sm leading-relaxed text-white/80">{s.t("hero.sub")}</p>
          <div className="fade-up mt-10 flex flex-wrap gap-3">
            <Link to="/shop" className="bg-white px-7 py-3 text-[11px] tracking-[0.22em] text-ink">
              {s.t("hero.cta").toUpperCase()}
            </Link>
            <Link to="/shop/promotions" className="border border-white/40 px-7 py-3 text-[11px] tracking-[0.22em]">
              {s.t("hero.cta2").toUpperCase()}
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 lg:px-8">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-serif text-3xl">{s.t("section.cats")}</h2>
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          {cats.map((c) => (
            <Link key={c.id} to={`/shop/${c.slug}`} className="group relative aspect-[3/4] overflow-hidden bg-[#efe8dc]">
              <img src={c.image} alt="" className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <span className="absolute bottom-4 start-4 font-serif text-2xl text-white">{s.tr(c.name)}</span>
            </Link>
          ))}
        </div>
      </section>

      <ProductRail title={s.t("section.popular")} to="/shop" products={popular} />
      <ProductRail title={s.t("section.new")} to="/shop/nouveautes" products={news} />

      <section className="relative my-8 overflow-hidden bg-ink text-white">
        <div className="mx-auto grid max-w-7xl md:grid-cols-2">
          <img src={BOUTIQUE_IMG} alt="" className="h-80 w-full object-cover md:h-full" />
          <div className="flex flex-col justify-center px-8 py-16 lg:px-16">
            <p className="text-[11px] uppercase tracking-[0.4em] text-[#c4a574]">{s.t("section.look")}</p>
            <h2 className="mt-4 font-serif text-4xl">{s.t("footer.about")}</h2>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-white/70">{s.t("footer.aboutText")}</p>
            <Link to="/shop/femme" className="mt-8 inline-flex items-center gap-2 text-[11px] tracking-[0.22em]">
              {s.t("hero.cta").toUpperCase()} <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <ProductRail title={s.t("section.sale")} to="/shop/promotions" products={sales} />
      <ProductRail title={s.t("section.bestsellers")} to="/shop" products={bestsellers} />
      <ProductRail title={s.t("section.reco")} to="/shop" products={reco} />

      <section className="mx-auto max-w-7xl px-4 py-6 lg:px-8">
        <Link
          to={s.currentUser ? "/admin" : "/admin/login"}
          className="flex flex-col items-start justify-between gap-4 border border-black/10 bg-[#161412] p-6 text-white sm:flex-row sm:items-center"
        >
          <div>
            <p className="text-[11px] uppercase tracking-[0.3em] text-[#c4a574]">{s.t("nav.admin")}</p>
            <h2 className="mt-2 font-serif text-3xl">{s.t("auth.adminLogin")}</h2>
            <p className="mt-2 text-sm text-white/60">{s.t("demo.hint")}</p>
          </div>
          <span className="bg-[#c4a574] px-6 py-3 text-[11px] tracking-[0.2em] text-ink">
            {s.t("nav.admin").toUpperCase()} →
          </span>
        </Link>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 lg:px-8">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { t: s.t("footer.shipping"), d: s.t("shipping.info") },
            { t: s.t("footer.returns"), d: s.lang === "ar" ? "إرجاع مجاني خلال 14 يوماً." : s.lang === "en" ? "Free returns within 14 days." : "Retours gratuits sous 14 jours." },
            { t: s.t("footer.service"), d: `${s.settings.phone} · ${s.settings.email}` },
          ].map((b) => (
            <div key={b.t} className="border border-black/10 p-6">
              <p className="text-[11px] uppercase tracking-[0.25em]">{b.t}</p>
              <p className="mt-2 text-sm text-mute">{b.d}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function ProductRail({ title, to, products }: { title: string; to: string; products: import("../types").Product[] }) {
  const s = useStore();
  return (
    <section className="mx-auto max-w-7xl px-4 py-12 lg:px-8">
      <div className="mb-8 flex items-end justify-between">
        <h2 className="font-serif text-3xl">{title}</h2>
        <Link to={to} className="text-[11px] uppercase tracking-[0.22em] text-mute hover:text-ink">
          {s.t("common.seeAll")}
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
        {products.filter((p) => productStock(p) >= 0).map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
