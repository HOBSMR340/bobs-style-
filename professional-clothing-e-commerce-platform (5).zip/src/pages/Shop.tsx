import { useMemo, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { SlidersHorizontal } from "lucide-react";
import { useStore } from "../store";
import { ProductCard } from "../components/ProductCard";
import { effectivePrice, isOnSale, productStock } from "../utils/helpers";

export default function Shop() {
  const s = useStore();
  const { category } = useParams();
  const [sp] = useSearchParams();
  const q = (sp.get("q") || "").toLowerCase();
  const [sort, setSort] = useState("featured");
  const [minP, setMinP] = useState("");
  const [maxP, setMaxP] = useState("");
  const [sizes, setSizes] = useState<string[]>([]);
  const [colors, setColors] = useState<string[]>([]);
  const [brands, setBrands] = useState<string[]>([]);
  const [inStock, setInStock] = useState(false);
  const [promo, setPromo] = useState(false);
  const [showF, setShowF] = useState(false);

  const cat = s.categories.find((c) => c.slug === category);

  const list = useMemo(() => {
    let items = s.products.filter((p) => p.status !== "hidden");
    if (category === "promotions") items = items.filter(isOnSale);
    else if (category === "nouveautes") items = items.filter((p) => p.isNew);
    else if (cat) {
      items = items.filter((p) => p.categoryId === cat.id || p.subcategoryId === cat.id || p.gender === (cat.slug as typeof p.gender));
    }
    if (q) {
      items = items.filter((p) => {
        const brand = s.brands.find((b) => b.id === p.brandId)?.name || "";
        return (
          s.tr(p.name).toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q) ||
          brand.toLowerCase().includes(q) ||
          p.colors.some((c) => c.name.toLowerCase().includes(q)) ||
          p.sizes.some((sz) => sz.toLowerCase().includes(q))
        );
      });
    }
    if (minP) items = items.filter((p) => effectivePrice(p) >= Number(minP));
    if (maxP) items = items.filter((p) => effectivePrice(p) <= Number(maxP));
    if (sizes.length) items = items.filter((p) => p.sizes.some((sz) => sizes.includes(sz)));
    if (colors.length) items = items.filter((p) => p.colors.some((c) => colors.includes(c.name)));
    if (brands.length) items = items.filter((p) => brands.includes(p.brandId));
    if (inStock) items = items.filter((p) => productStock(p) > 0);
    if (promo) items = items.filter(isOnSale);

    items = [...items].sort((a, b) => {
      if (sort === "newest") return +new Date(b.createdAt) - +new Date(a.createdAt);
      if (sort === "priceAsc") return effectivePrice(a) - effectivePrice(b);
      if (sort === "priceDesc") return effectivePrice(b) - effectivePrice(a);
      if (sort === "name") return s.tr(a.name).localeCompare(s.tr(b.name));
      return Number(b.featured) - Number(a.featured);
    });
    return items;
  }, [s.products, s.lang, category, q, sort, minP, maxP, sizes, colors, brands, inStock, promo, cat]);

  const allSizes = [...new Set(s.products.flatMap((p) => p.sizes))];
  const allColors = [...new Set(s.products.flatMap((p) => p.colors.map((c) => c.name)))];

  const title = cat ? s.tr(cat.name) : category === "promotions" ? s.t("nav.sale") : category === "nouveautes" ? s.t("nav.new") : s.t("nav.shop");

  const toggle = (arr: string[], v: string, set: (x: string[]) => void) =>
    set(arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 lg:px-8">
      <div className="mb-8">
        <p className="text-[11px] uppercase tracking-[0.3em] text-mute">{s.tr(s.settings.storeName)}</p>
        <h1 className="mt-1 font-serif text-4xl">{title}</h1>
        <p className="mt-2 text-sm text-mute">
          {list.length} {s.lang === "ar" ? "منتج" : s.lang === "en" ? "products" : "produits"}
        </p>
      </div>

      <div className="mb-6 flex items-center justify-between gap-3">
        <button onClick={() => setShowF((v) => !v)} className="flex items-center gap-2 border border-black/15 px-3 py-2 text-xs uppercase tracking-widest lg:hidden">
          <SlidersHorizontal className="h-4 w-4" /> {s.t("common.filter")}
        </button>
        <select value={sort} onChange={(e) => setSort(e.target.value)} className="border border-black/15 bg-transparent px-3 py-2 text-xs">
          <option value="featured">{s.t("sort.featured")}</option>
          <option value="newest">{s.t("sort.newest")}</option>
          <option value="priceAsc">{s.t("sort.priceAsc")}</option>
          <option value="priceDesc">{s.t("sort.priceDesc")}</option>
          <option value="name">{s.t("sort.name")}</option>
        </select>
      </div>

      <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
        <aside className={`${showF ? "block" : "hidden"} space-y-6 lg:block`}>
          <FilterBlock title={s.t("filter.price")}>
            <div className="flex gap-2">
              <input value={minP} onChange={(e) => setMinP(e.target.value)} placeholder="Min" className="w-full border border-black/10 px-2 py-1 text-sm" />
              <input value={maxP} onChange={(e) => setMaxP(e.target.value)} placeholder="Max" className="w-full border border-black/10 px-2 py-1 text-sm" />
            </div>
          </FilterBlock>
          <FilterBlock title={s.t("filter.size")}>
            <div className="flex flex-wrap gap-1">
              {allSizes.map((sz) => (
                <button
                  key={sz}
                  onClick={() => toggle(sizes, sz, setSizes)}
                  className={`border px-2 py-1 text-xs ${sizes.includes(sz) ? "border-ink bg-ink text-white" : "border-black/15"}`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </FilterBlock>
          <FilterBlock title={s.t("filter.color")}>
            <div className="flex flex-wrap gap-2">
              {allColors.map((c) => (
                <button
                  key={c}
                  onClick={() => toggle(colors, c, setColors)}
                  className={`text-xs ${colors.includes(c) ? "underline" : ""}`}
                >
                  {c}
                </button>
              ))}
            </div>
          </FilterBlock>
          <FilterBlock title={s.t("filter.brand")}>
            {s.brands.map((b) => (
              <label key={b.id} className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={brands.includes(b.id)} onChange={() => toggle(brands, b.id, setBrands)} />
                {b.name}
              </label>
            ))}
          </FilterBlock>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={inStock} onChange={(e) => setInStock(e.target.checked)} />
            {s.t("filter.inStock")}
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={promo} onChange={(e) => setPromo(e.target.checked)} />
            {s.t("filter.promo")}
          </label>
        </aside>
        <div>
          {list.length === 0 ? (
            <p className="py-20 text-center text-mute">{s.t("common.empty")}</p>
          ) : (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-6">
              {list.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function FilterBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-2 text-[11px] uppercase tracking-[0.2em]">{title}</p>
      {children}
    </div>
  );
}
