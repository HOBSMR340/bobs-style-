import { useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Heart, Truck } from "lucide-react";
import { useStore } from "../store";
import { ProductCard } from "../components/ProductCard";
import { discountPercent, effectivePrice, isOnSale, productStock } from "../utils/helpers";

export default function ProductPage() {
  const { id } = useParams();
  const s = useStore();
  const nav = useNavigate();
  const p = s.products.find((x) => x.id === id);
  const [img, setImg] = useState(0);
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState<"d" | "i" | "s">("d");
  const [msg, setMsg] = useState("");

  const variant = useMemo(
    () => p?.variants.find((v) => (!size || v.size === size) && (!color || v.color === color)),
    [p, size, color]
  );

  if (!p || p.status === "hidden") {
    return (
      <div className="py-24 text-center">
        <p>{s.t("common.empty")}</p>
        <Link to="/shop" className="mt-4 inline-block underline">
          {s.t("cart.continue")}
        </Link>
      </div>
    );
  }
  const price = effectivePrice(p);
  const sale = isOnSale(p);
  const stock = variant ? variant.stock : productStock(p);
  const related = s.products.filter((x) => x.id !== p.id && x.categoryId === p.categoryId && x.status !== "hidden").slice(0, 4);
  const brand = s.brands.find((b) => b.id === p.brandId);

  const add = (buy?: boolean) => {
    if (!size && p.sizes.length && p.sizes[0] !== "U") {
      setMsg(s.t("product.selectSize"));
      return;
    }
    const v =
      variant ||
      p.variants.find((x) => x.stock > 0) ||
      p.variants[0];
    if (!v) return;
    const res = s.addToCart(p.id, v.id, qty);
    if (!res.ok) {
      setMsg(res.error || s.t("common.outOfStock"));
      return;
    }
    setMsg(s.t("product.added"));
    if (buy) nav("/checkout");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 lg:px-8">
      <div className="grid gap-10 lg:grid-cols-2">
        <div>
          <div className="aspect-[3/4] overflow-hidden bg-[#efe8dc]">
            <img src={p.images[img] || p.images[0]} alt={s.tr(p.name)} className="h-full w-full object-cover" />
          </div>
          {p.images.length > 1 && (
            <div className="mt-3 grid grid-cols-5 gap-2">
              {p.images.map((src, i) => (
                <button key={i} onClick={() => setImg(i)} className={`aspect-[3/4] overflow-hidden border ${img === i ? "border-ink" : "border-transparent"}`}>
                  <img src={src} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
        <div>
          <p className="text-[11px] uppercase tracking-[0.25em] text-mute">{brand?.name} · {p.sku}</p>
          <h1 className="mt-2 font-serif text-4xl">{s.tr(p.name)}</h1>
          <div className="mt-4 flex items-center gap-3">
            <span className="text-2xl">{s.formatPrice(price)}</span>
            {sale && p.oldPrice && <span className="text-mute line-through">{s.formatPrice(p.oldPrice)}</span>}
            {sale && <span className="bg-[#8b2e2e] px-2 py-0.5 text-[11px] text-white">-{discountPercent(p)}%</span>}
          </div>
          <p className="mt-6 text-sm leading-relaxed text-mute">{s.tr(p.description)}</p>

          {p.colors.length > 0 && (
            <div className="mt-8">
              <p className="text-[11px] uppercase tracking-[0.2em]">
                {s.t("common.color")} {color && `— ${color}`}
              </p>
              <div className="mt-2 flex gap-2">
                {p.colors.map((c) => (
                  <button
                    key={c.name}
                    title={c.name}
                    onClick={() => setColor(c.name)}
                    className={`h-8 w-8 rounded-full border-2 ${color === c.name ? "border-ink" : "border-transparent"}`}
                    style={{ background: c.hex, boxShadow: "inset 0 0 0 1px rgba(0,0,0,.15)" }}
                  />
                ))}
              </div>
            </div>
          )}

          {p.sizes[0] !== "U" && (
            <div className="mt-6">
              <p className="text-[11px] uppercase tracking-[0.2em]">{s.t("common.size")}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {p.sizes.map((sz) => {
                  const st = p.variants.find((v) => v.size === sz && (!color || v.color === color))?.stock ?? 0;
                  return (
                    <button
                      key={sz}
                      disabled={st === 0}
                      onClick={() => setSize(sz)}
                      className={`min-w-12 border px-3 py-2 text-sm ${size === sz ? "border-ink bg-ink text-white" : "border-black/15"} ${st === 0 ? "opacity-30" : ""}`}
                    >
                      {sz}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="mt-6 flex items-center gap-3">
            <div className="flex border border-black/15">
              <button className="px-3 py-2" onClick={() => setQty(Math.max(1, qty - 1))}>−</button>
              <span className="min-w-8 py-2 text-center">{qty}</span>
              <button className="px-3 py-2" onClick={() => setQty(qty + 1)}>+</button>
            </div>
            <p className="text-xs text-mute">
              {stock > 0 ? `${stock} ${s.t("product.left")}` : s.t("common.outOfStock")}
              {variant && variant.stock <= variant.minStock && variant.stock > 0 && ` · ${s.t("common.lowStock")}`}
            </p>
          </div>

          {msg && <p className="mt-4 text-sm text-[#8b2e2e]">{msg}</p>}

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <button
              onClick={() => add()}
              disabled={stock === 0}
              className="flex-1 bg-ink py-3 text-[11px] tracking-[0.22em] text-white disabled:opacity-40"
            >
              {s.t("common.addToCart").toUpperCase()}
            </button>
            <button onClick={() => add(true)} className="flex-1 border border-ink py-3 text-[11px] tracking-[0.22em]">
              {s.t("common.buyNow").toUpperCase()}
            </button>
            <button onClick={() => s.toggleWishlist(p.id)} className="border border-black/15 px-4">
              <Heart className={`h-5 w-5 ${s.wishlist.includes(p.id) ? "fill-[#8b2e2e] text-[#8b2e2e]" : ""}`} />
            </button>
          </div>

          <div className="mt-8 flex items-start gap-3 border-t border-black/10 pt-6 text-sm text-mute">
            <Truck className="mt-0.5 h-4 w-4" />
            {s.t("shipping.info")}
          </div>

          <div className="mt-8 flex gap-6 text-[11px] uppercase tracking-[0.2em]">
            {(["d", "i", "s"] as const).map((k) => (
              <button key={k} onClick={() => setTab(k)} className={tab === k ? "border-b border-ink pb-1" : "text-mute"}>
                {k === "d" ? s.t("product.description") : k === "i" ? s.t("product.details") : s.t("product.shipping")}
              </button>
            ))}
          </div>
          <div className="mt-4 text-sm leading-relaxed text-mute">
            {tab === "d" && s.tr(p.description)}
            {tab === "i" && (
              <ul className="space-y-1">
                <li>{s.t("common.brand")}: {brand?.name}</li>
                <li>{s.t("common.sku")}: {p.sku}</li>
                <li>{s.t("common.material")}: {s.tr(p.material)}</li>
                <li>{s.t("product.gender")}: {p.gender}</li>
                {p.ageRange && <li>{s.t("product.age")}: {p.ageRange}</li>}
                {p.weight && <li>{s.t("product.weight")}: {p.weight} g</li>}
                {p.dimensions && <li>{s.t("product.dimensions")}: {p.dimensions}</li>}
              </ul>
            )}
            {tab === "s" && s.t("shipping.info")}
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-20">
          <h2 className="mb-8 font-serif text-3xl">{s.t("product.related")}</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {related.map((r) => (
              <ProductCard key={r.id} product={r} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
