import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useStore } from "../store";
import { formatDate } from "../utils/helpers";

export default function Account() {
  const s = useStore();
  const nav = useNavigate();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [form, setForm] = useState({ firstName: "", lastName: "", phone: "", address: "", city: "Alger", wilaya: "Alger" });

  if (!s.currentCustomer) {
    const submit = (e: React.FormEvent) => {
      e.preventDefault();
      if (mode === "login") {
        const c = s.loginCustomer(email, password);
        if (!c) setErr(s.t("auth.error"));
      } else {
        if (!form.firstName || !email || !password) {
          setErr(s.t("common.required"));
          return;
        }
        s.registerCustomer({ ...form, email, password });
      }
    };
    return (
      <div className="mx-auto max-w-md px-4 py-16">
        <h1 className="text-center font-serif text-4xl">{mode === "login" ? s.t("auth.login") : s.t("auth.register")}</h1>
        <form onSubmit={submit} className="mt-8 space-y-4">
          {mode === "register" && (
            <>
              <input placeholder={s.t("checkout.firstName")} className="w-full border border-black/15 px-3 py-2" value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
              <input placeholder={s.t("checkout.lastName")} className="w-full border border-black/15 px-3 py-2" value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
              <input placeholder={s.t("checkout.phone")} className="w-full border border-black/15 px-3 py-2" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </>
          )}
          <input placeholder={s.t("checkout.email")} className="w-full border border-black/15 px-3 py-2" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input type="password" placeholder={s.t("auth.password")} className="w-full border border-black/15 px-3 py-2" value={password} onChange={(e) => setPassword(e.target.value)} />
          {err && <p className="text-sm text-[#8b2e2e]">{err}</p>}
          <button className="w-full bg-ink py-3 text-[11px] tracking-[0.22em] text-white">
            {(mode === "login" ? s.t("auth.login") : s.t("auth.register")).toUpperCase()}
          </button>
        </form>
        <button className="mt-4 w-full text-sm underline" onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? s.t("auth.noAccount") : s.t("auth.hasAccount")}
        </button>
        <p className="mt-6 text-center text-xs text-mute">sarah@email.com / client123</p>
      </div>
    );
  }

  const cust = s.currentCustomer;
  const orders = s.orders.filter((o) => o.customerId === cust.id);

  return (
    <div className="mx-auto max-w-5xl px-4 py-12">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-serif text-4xl">{s.t("account.title")}</h1>
          <p className="mt-1 text-mute">
            {s.currentCustomer.firstName} {s.currentCustomer.lastName}
          </p>
        </div>
        <button
          onClick={() => {
            s.logoutCustomer();
            nav("/");
          }}
          className="text-xs underline"
        >
          {s.t("nav.logout")}
        </button>
      </div>
      <h2 className="mt-10 text-[11px] uppercase tracking-[0.25em]">{s.t("account.orders")}</h2>
      {orders.length === 0 ? (
        <p className="mt-4 text-mute">{s.t("account.noOrders")}</p>
      ) : (
        <div className="mt-4 divide-y divide-black/10 border border-black/10">
          {orders.map((o) => (
            <Link key={o.id} to={`/order/${o.id}`} className="flex items-center justify-between p-4 hover:bg-[#f6f1e8]">
              <div>
                <p className="font-medium">{o.number}</p>
                <p className="text-xs text-mute">{formatDate(o.createdAt, s.lang)} · {s.t(`order.${o.status}`)}</p>
              </div>
              <p>{s.formatPrice(o.total)}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

export function Wishlist() {
  const s = useStore();
  const items = s.products.filter((p) => s.wishlist.includes(p.id));
  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <h1 className="font-serif text-4xl">{s.t("nav.wishlist")}</h1>
      {items.length === 0 ? (
        <p className="mt-8 text-mute">{s.t("common.empty")}</p>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
          {items.map((p) => (
            <Link key={p.id} to={`/product/${p.id}`}>
              <img src={p.images[0]} className="aspect-[3/4] w-full object-cover" alt="" />
              <p className="mt-2 font-serif">{s.tr(p.name)}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
