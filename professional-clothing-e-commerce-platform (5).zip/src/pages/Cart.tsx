import { Link } from "react-router-dom";
import { useStore } from "../store";
import { effectivePrice } from "../utils/helpers";

export default function Cart() {
  const s = useStore();
  const rows = s.cart.map((ci) => {
    const p = s.products.find((x) => x.id === ci.productId);
    const v = p?.variants.find((x) => x.id === ci.variantId);
    return { ci, p, v };
  });
  const subtotal = rows.reduce((sum, r) => (r.p ? sum + effectivePrice(r.p) * r.ci.quantity : sum), 0);
  const shipping = subtotal >= s.settings.freeShippingFrom ? 0 : s.settings.shippingFee;

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 lg:px-8">
      <h1 className="font-serif text-4xl">{s.t("cart.title")}</h1>
      {rows.length === 0 ? (
        <div className="py-20 text-center">
          <p className="font-serif text-2xl">{s.t("cart.empty")}</p>
          <p className="mt-2 text-mute">{s.t("cart.emptyHint")}</p>
          <Link to="/shop" className="mt-8 inline-block bg-ink px-8 py-3 text-[11px] tracking-[0.22em] text-white">
            {s.t("cart.continue").toUpperCase()}
          </Link>
        </div>
      ) : (
        <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_320px]">
          <div className="divide-y divide-black/10">
            {rows.map(({ ci, p, v }) =>
              p && v ? (
                <div key={ci.variantId} className="flex gap-4 py-6">
                  <Link to={`/product/${p.id}`}>
                    <img src={p.images[0]} alt="" className="h-32 w-24 object-cover" />
                  </Link>
                  <div className="flex-1">
                    <Link to={`/product/${p.id}`} className="font-serif text-xl">
                      {s.tr(p.name)}
                    </Link>
                    <p className="mt-1 text-xs text-mute">
                      {s.t("common.color")}: {v.color} · {s.t("common.size")}: {v.size}
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-3">
                      <select
                        value={v.id}
                        onChange={(e) => s.updateCartVariant(v.id, e.target.value)}
                        className="border border-black/15 bg-transparent px-2 py-1 text-xs"
                      >
                        {p.variants.map((opt) => (
                          <option key={opt.id} value={opt.id} disabled={opt.stock === 0}>
                            {opt.color} / {opt.size} ({opt.stock})
                          </option>
                        ))}
                      </select>
                      <div className="flex border border-black/15">
                        <button className="px-2" onClick={() => s.updateCartQty(v.id, ci.quantity - 1)}>−</button>
                        <span className="px-3 py-1 text-sm">{ci.quantity}</span>
                        <button className="px-2" onClick={() => s.updateCartQty(v.id, Math.min(v.stock, ci.quantity + 1))}>+</button>
                      </div>
                      <button onClick={() => s.removeFromCart(v.id)} className="text-xs underline">
                        {s.t("cart.remove")}
                      </button>
                    </div>
                  </div>
                  <p className="font-medium">{s.formatPrice(effectivePrice(p) * ci.quantity)}</p>
                </div>
              ) : null
            )}
          </div>
          <aside className="h-fit border border-black/10 p-6">
            <h2 className="text-[11px] uppercase tracking-[0.25em]">{s.t("common.total")}</h2>
            <div className="mt-4 space-y-2 text-sm">
              <Row l={s.t("common.subtotal")} r={s.formatPrice(subtotal)} />
              <Row l={s.t("common.shipping")} r={shipping === 0 ? s.t("common.free") : s.formatPrice(shipping)} />
              {s.settings.taxEnabled && <Row l={s.t("common.tax")} r={s.formatPrice(Math.round(subtotal - subtotal / (1 + s.settings.taxRate / 100)))} />}
              <div className="flex justify-between border-t border-black/10 pt-3 text-base font-medium">
                <span>{s.t("common.total")}</span>
                <span>{s.formatPrice(subtotal + shipping)}</span>
              </div>
            </div>
            <Link to="/checkout" className="mt-6 block bg-ink py-3 text-center text-[11px] tracking-[0.22em] text-white">
              {s.t("cart.checkout").toUpperCase()}
            </Link>
            <Link to="/shop" className="mt-3 block text-center text-xs underline">
              {s.t("cart.continue")}
            </Link>
          </aside>
        </div>
      )}
    </div>
  );
}

function Row({ l, r }: { l: string; r: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-mute">{l}</span>
      <span>{r}</span>
    </div>
  );
}
