import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useStore } from "../store";
import { effectivePrice, WILAYA_LIST } from "../utils/helpers";

export default function Checkout() {
  const s = useStore();
  const nav = useNavigate();
  const c = s.currentCustomer;
  const [form, setForm] = useState({
    firstName: c?.firstName || "",
    lastName: c?.lastName || "",
    phone: c?.phone || "",
    email: c?.email || "",
    address: c?.address || "",
    city: c?.city || "",
    wilaya: c?.wilaya || "Alger",
    notes: "",
    payment: "cod" as const,
  });
  const [err, setErr] = useState("");

  const rows = s.cart.map((ci) => {
    const p = s.products.find((x) => x.id === ci.productId)!;
    const v = p.variants.find((x) => x.id === ci.variantId)!;
    return { ci, p, v };
  });
  const subtotal = rows.reduce((sum, r) => sum + effectivePrice(r.p) * r.ci.quantity, 0);
  const zone = s.settings.zones.find((z) => z.wilaya === form.wilaya);
  const shipping = subtotal >= s.settings.freeShippingFrom ? 0 : zone?.fee ?? s.settings.shippingFee;

  if (s.cart.length === 0) {
    return (
      <div className="py-24 text-center">
        <p>{s.t("cart.empty")}</p>
        <Link to="/shop" className="mt-4 inline-block underline">{s.t("cart.continue")}</Link>
      </div>
    );
  }

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.firstName || !form.lastName || !form.phone || !form.address || !form.city) {
      setErr(s.t("common.required"));
      return;
    }
    const order = s.placeOrder({
      guest: c ? undefined : { firstName: form.firstName, lastName: form.lastName, phone: form.phone, email: form.email },
      address: {
        firstName: form.firstName,
        lastName: form.lastName,
        phone: form.phone,
        email: form.email,
        address: form.address,
        city: form.city,
        wilaya: form.wilaya,
      },
      paymentMethod: form.payment,
      notes: form.notes,
    });
    nav(`/order/${order.id}`);
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 lg:px-8">
      <h1 className="font-serif text-4xl">{s.t("checkout.title")}</h1>
      <form onSubmit={submit} className="mt-10 grid gap-10 lg:grid-cols-[1fr_340px]">
        <div className="space-y-6">
          <h2 className="text-[11px] uppercase tracking-[0.25em]">{s.t("checkout.info")}</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={s.t("checkout.firstName")} value={form.firstName} onChange={(v) => set("firstName", v)} />
            <Field label={s.t("checkout.lastName")} value={form.lastName} onChange={(v) => set("lastName", v)} />
            <Field label={s.t("checkout.phone")} value={form.phone} onChange={(v) => set("phone", v)} />
            <Field label={s.t("checkout.email")} value={form.email} onChange={(v) => set("email", v)} />
            <div className="sm:col-span-2">
              <Field label={s.t("checkout.address")} value={form.address} onChange={(v) => set("address", v)} />
            </div>
            <Field label={s.t("checkout.city")} value={form.city} onChange={(v) => set("city", v)} />
            <label className="block text-xs">
              <span className="text-mute">{s.t("checkout.wilaya")}</span>
              <select value={form.wilaya} onChange={(e) => set("wilaya", e.target.value)} className="mt-1 w-full border border-black/15 bg-transparent px-3 py-2">
                {WILAYA_LIST.map((w) => (
                  <option key={w}>{w}</option>
                ))}
              </select>
            </label>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.25em]">{s.t("checkout.payment")}</p>
            <label className="mt-3 flex items-center gap-2 text-sm">
              <input type="radio" checked readOnly /> {s.t("checkout.cod")}
            </label>
            {!s.settings.payments.card && (
              <p className="mt-1 text-xs text-mute">
                {s.lang === "ar" ? "بطاقة بنكية غير مفعّلة" : s.lang === "en" ? "Card payments disabled" : "Carte bancaire désactivée"}
              </p>
            )}
          </div>
          <label className="block text-xs">
            <span className="text-mute">{s.t("checkout.notes")}</span>
            <textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} className="mt-1 w-full border border-black/15 bg-transparent px-3 py-2" rows={3} />
          </label>
          {err && <p className="text-sm text-[#8b2e2e]">{err}</p>}
        </div>
        <aside className="h-fit border border-black/10 p-6">
          {rows.map(({ ci, p, v }) => (
            <div key={v.id} className="mb-3 flex gap-3 text-sm">
              <img src={p.images[0]} className="h-16 w-12 object-cover" alt="" />
              <div className="flex-1">
                <p>{s.tr(p.name)}</p>
                <p className="text-xs text-mute">{v.color} / {v.size} × {ci.quantity}</p>
              </div>
            </div>
          ))}
          <div className="mt-4 space-y-2 border-t border-black/10 pt-4 text-sm">
            <div className="flex justify-between"><span>{s.t("common.subtotal")}</span><span>{s.formatPrice(subtotal)}</span></div>
            <div className="flex justify-between"><span>{s.t("common.shipping")}</span><span>{shipping === 0 ? s.t("common.free") : s.formatPrice(shipping)}</span></div>
            <div className="flex justify-between font-medium"><span>{s.t("common.total")}</span><span>{s.formatPrice(subtotal + shipping)}</span></div>
          </div>
          <button className="mt-6 w-full bg-ink py-3 text-[11px] tracking-[0.22em] text-white">
            {s.t("checkout.place").toUpperCase()}
          </button>
        </aside>
      </form>
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block text-xs">
      <span className="text-mute">{label}</span>
      <input value={value} onChange={(e) => onChange(e.target.value)} className="mt-1 w-full border border-black/15 bg-transparent px-3 py-2" />
    </label>
  );
}
