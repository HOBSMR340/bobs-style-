import { Heart, ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";
import { useStore } from "../store";
import { discountPercent, effectivePrice, isOnSale, productStock } from "../utils/helpers";
import type { Product } from "../types";

export function ProductCard({ product }: { product: Product }) {
  const s = useStore();
  const price = effectivePrice(product);
  const off = discountPercent(product);
  const sale = isOnSale(product);
  const stock = productStock(product);
  const loved = s.wishlist.includes(product.id);

  return (
    <article className="group relative">
      <Link to={`/product/${product.id}`} className="block overflow-hidden bg-[#efe8dc]">
        <div className="relative aspect-[3/4] overflow-hidden">
          <img
            src={product.images[0]}
            alt={s.tr(product.name)}
            className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
          />
          {product.images[1] && (
            <img
              src={product.images[1]}
              alt=""
              className="absolute inset-0 h-full w-full object-cover opacity-0 transition duration-700 group-hover:opacity-100"
            />
          )}
          <div className="absolute start-3 top-3 flex flex-col gap-1">
            {sale && (
              <span className="bg-[#8b2e2e] px-2 py-0.5 text-[10px] font-medium tracking-widest text-white">
                -{off}%
              </span>
            )}
            {product.isNew && (
              <span className="bg-white/90 px-2 py-0.5 text-[10px] font-medium tracking-widest text-ink">
                NEW
              </span>
            )}
            {stock === 0 && (
              <span className="bg-ink/80 px-2 py-0.5 text-[10px] font-medium tracking-widest text-white">
                {s.t("common.outOfStock")}
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              s.toggleWishlist(product.id);
            }}
            className="absolute end-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-ink opacity-0 transition group-hover:opacity-100"
            aria-label="wishlist"
          >
            <Heart className={`h-4 w-4 ${loved ? "fill-[#8b2e2e] text-[#8b2e2e]" : ""}`} />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              const v = product.variants.find((x) => x.stock > 0) || product.variants[0];
              if (v) s.addToCart(product.id, v.id, 1);
            }}
            className="absolute inset-x-3 bottom-3 flex items-center justify-center gap-2 bg-ink py-2.5 text-[11px] font-medium tracking-[0.18em] text-white opacity-0 transition group-hover:opacity-100"
          >
            <ShoppingBag className="h-3.5 w-3.5" />
            {s.t("common.addToCart").toUpperCase()}
          </button>
        </div>
      </Link>
      <div className="mt-3 space-y-1">
        <p className="text-[10px] uppercase tracking-[0.2em] text-mute">
          {s.brands.find((b) => b.id === product.brandId)?.name}
        </p>
        <Link to={`/product/${product.id}`} className="block font-serif text-lg leading-tight text-ink">
          {s.tr(product.name)}
        </Link>
        <div className="flex items-center gap-2 text-sm">
          <span className="font-medium">{s.formatPrice(price)}</span>
          {sale && product.oldPrice && (
            <span className="text-mute line-through">{s.formatPrice(product.oldPrice)}</span>
          )}
        </div>
        <div className="flex gap-1 pt-1">
          {product.colors.slice(0, 5).map((c) => (
            <span
              key={c.name}
              title={c.name}
              className="h-3 w-3 rounded-full border border-black/15"
              style={{ background: c.hex }}
            />
          ))}
        </div>
      </div>
    </article>
  );
}
