import { useEffect, useMemo, useState } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { Heart, Menu, Search, ShoppingBag, User, X, Globe, ChevronDown, Shield } from "lucide-react";
import { useStore } from "../store";
import { LANG_META } from "../i18n";
import type { Currency, Lang } from "../types";
import { effectivePrice } from "../utils/helpers";

const NAV = [
  { to: "/shop/homme", key: "nav.men" },
  { to: "/shop/femme", key: "nav.women" },
  { to: "/shop/enfant", key: "nav.kids" },
  { to: "/shop/chaussures", key: "nav.shoes" },
  { to: "/shop/accessoires", key: "nav.accessories" },
  { to: "/shop/nouveautes", key: "nav.new" },
  { to: "/shop/promotions", key: "nav.sale" },
];

export function Layout() {
  const s = useStore();
  const loc = useLocation();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState("");
  const cartCount = s.cart.reduce((n, i) => n + i.quantity, 0);

  useEffect(() => {
    setOpen(false);
    setSearchOpen(false);
    window.scrollTo(0, 0);
  }, [loc.pathname]);

  const results = useMemo(() => {
    if (q.trim().length < 1) return [];
    const n = q.toLowerCase();
    return s.products
      .filter((p) => p.status !== "hidden")
      .filter((p) => {
        const brand = s.brands.find((b) => b.id === p.brandId)?.name || "";
        const cat = s.categories.find((c) => c.id === p.categoryId);
        return (
          s.tr(p.name).toLowerCase().includes(n) ||
          p.sku.toLowerCase().includes(n) ||
          brand.toLowerCase().includes(n) ||
          s.tr(cat?.name).toLowerCase().includes(n) ||
          p.colors.some((c) => c.name.toLowerCase().includes(n)) ||
          p.sizes.some((sz) => sz.toLowerCase().includes(n)) ||
          p.tags.some((t) => t.toLowerCase().includes(n))
        );
      })
      .slice(0, 8);
  }, [q, s.products, s.lang]);

  return (
    <div className={`min-h-screen bg-[#faf7f2] text-ink ${s.settings.darkMode ? "dark bg-[#0e0e0e] text-[#f3eee6]" : ""}`}>
      <div className="bg-ink text-center text-[11px] tracking-[0.18em] text-[#f6f1e8]">
        <p className="px-4 py-2">{s.t("banner.promo")}</p>
      </div>

      <header className="sticky top-0 z-40 border-b border-black/5 bg-[#faf7f2]/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 lg:px-8">
          <button className="lg:hidden" onClick={() => setOpen(true)} aria-label="menu">
            <Menu className="h-6 w-6" />
          </button>
          <Link to="/" className="font-serif text-2xl tracking-[0.35em] lg:text-3xl">
            VELORA
          </Link>
          <nav className="hidden items-center gap-6 text-[12px] uppercase tracking-[0.18em] lg:flex">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                className={({ isActive }) =>
                  `pb-0.5 transition hover:text-gold-dark ${isActive ? "border-b border-ink" : "text-ink/80"}`
                }
              >
                {s.t(n.key)}
              </NavLink>
            ))}
          </nav>
          <div className="flex items-center gap-2 sm:gap-3">
            <LangCurrency />
            <button onClick={() => setSearchOpen(true)} aria-label="search" className="p-1">
              <Search className="h-5 w-5" />
            </button>
            <Link to="/account" className="p-1" aria-label="account">
              <User className="h-5 w-5" />
            </Link>
            <Link to="/wishlist" className="relative hidden p-1 sm:block" aria-label="wishlist">
              <Heart className="h-5 w-5" />
              {s.wishlist.length > 0 && (
                <span className="absolute -end-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-ink text-[9px] text-white">
                  {s.wishlist.length}
                </span>
              )}
            </Link>
            <Link to="/cart" className="relative p-1" aria-label="cart">
              <ShoppingBag className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -end-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-ink text-[9px] text-white">
                  {cartCount}
                </span>
              )}
            </Link>
            <Link
              to={s.currentUser ? "/admin" : "/admin/login"}
              className="hidden items-center gap-1.5 bg-ink px-3 py-1.5 text-[10px] uppercase tracking-[0.18em] text-white sm:inline-flex"
            >
              <Shield className="h-3.5 w-3.5" />
              {s.t("nav.admin")}
            </Link>
          </div>
        </div>
      </header>

      {open && (
        <div className="fixed inset-0 z-50 bg-black/40 lg:hidden" onClick={() => setOpen(false)}>
          <aside
            className="absolute inset-y-0 start-0 w-[82%] max-w-sm bg-[#faf7f2] p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-8 flex items-center justify-between">
              <span className="font-serif text-2xl tracking-[0.3em]">VELORA</span>
              <button onClick={() => setOpen(false)}>
                <X />
              </button>
            </div>
            <nav className="flex flex-col gap-4 text-lg">
              {NAV.map((n) => (
                <Link key={n.to} to={n.to} className="font-serif">
                  {s.t(n.key)}
                </Link>
              ))}
              <Link to="/account">{s.t("nav.account")}</Link>
              <Link to={s.currentUser ? "/admin" : "/admin/login"} className="flex items-center gap-2 font-serif text-[#9a7b4f]">
                <Shield className="h-4 w-4" />
                {s.t("nav.admin")}
              </Link>
            </nav>
          </aside>
        </div>
      )}

      {searchOpen && (
        <div className="fixed inset-0 z-50 bg-black/50" onClick={() => setSearchOpen(false)}>
          <div className="mx-auto mt-10 max-w-2xl px-4" onClick={(e) => e.stopPropagation()}>
            <div className="bg-white p-4 shadow-2xl">
              <div className="flex items-center gap-3 border-b border-black/10 pb-3">
                <Search className="h-5 w-5 text-mute" />
                <input
                  autoFocus
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      nav(`/shop?q=${encodeURIComponent(q)}`);
                      setSearchOpen(false);
                    }
                  }}
                  placeholder={s.t("nav.search")}
                  className="w-full bg-transparent text-lg outline-none"
                />
                <button onClick={() => setSearchOpen(false)}>
                  <X className="h-5 w-5" />
                </button>
              </div>
              <ul className="max-h-[60vh] overflow-auto pt-2">
                {results.map((p) => (
                  <li key={p.id}>
                    <Link
                      to={`/product/${p.id}`}
                      className="flex items-center gap-3 px-2 py-2 hover:bg-[#f6f1e8]"
                    >
                      <img src={p.images[0]} alt="" className="h-14 w-11 object-cover" />
                      <div className="flex-1">
                        <p className="font-serif">{s.tr(p.name)}</p>
                        <p className="text-xs text-mute">{p.sku}</p>
                      </div>
                      <span className="text-sm">{s.formatPrice(effectivePrice(p))}</span>
                    </Link>
                  </li>
                ))}
                {q && results.length === 0 && <p className="p-4 text-sm text-mute">{s.t("common.empty")}</p>}
              </ul>
            </div>
          </div>
        </div>
      )}

      <main>
        <Outlet />
      </main>

      <footer className="mt-20 border-t border-black/10 bg-[#1a1714] text-[#f3eee6]">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 md:grid-cols-4 lg:px-8">
          <div>
            <p className="font-serif text-2xl tracking-[0.3em]">{s.tr(s.settings.storeName)}</p>
            <p className="mt-4 text-sm leading-relaxed text-white/70">{s.t("footer.aboutText")}</p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.25em]">{s.t("footer.help")}</p>
            <ul className="mt-4 space-y-2 text-sm text-white/70">
              <li>{s.t("footer.shipping")}</li>
              <li>{s.t("footer.returns")}</li>
              <li>{s.t("footer.faq")}</li>
              <li>{s.t("footer.contact")}</li>
            </ul>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.25em]">{s.t("footer.service")}</p>
            <ul className="mt-4 space-y-2 text-sm text-white/70">
              <li>{s.settings.email}</li>
              <li>{s.settings.phone}</li>
              <li>{s.settings.address}</li>
              <li>
                <Link to="/admin/login" className="underline-offset-4 hover:underline">
                  {s.t("nav.admin")}
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.25em]">{s.t("footer.newsletter")}</p>
            <form
              className="mt-4 flex border border-white/20"
              onSubmit={(e) => {
                e.preventDefault();
                alert(s.lang === "ar" ? "شكراً لاشتراكك" : s.lang === "en" ? "Thanks for subscribing" : "Merci pour votre inscription");
              }}
            >
              <input
                className="w-full bg-transparent px-3 py-2 text-sm outline-none"
                placeholder={s.t("footer.email")}
              />
              <button className="bg-[#c4a574] px-4 text-xs tracking-widest text-ink">{s.t("footer.subscribe")}</button>
            </form>
            <p className="mt-4 text-[11px] text-white/40">{s.t("demo.hint")}</p>
          </div>
        </div>
        <div className="border-t border-white/10 py-4 text-center text-[11px] tracking-widest text-white/40">
          © {new Date().getFullYear()} VELORA — {s.t("footer.rights")}
        </div>
      </footer>

      <Link
        to={s.currentUser ? "/admin" : "/admin/login"}
        className="fixed bottom-5 end-5 z-40 flex items-center gap-2 rounded-full bg-ink px-4 py-3 text-[11px] uppercase tracking-[0.18em] text-white shadow-xl sm:hidden"
      >
        <Shield className="h-4 w-4" />
        {s.t("nav.admin")}
      </Link>
    </div>
  );
}

function LangCurrency() {
  const s = useStore();
  const [open, setOpen] = useState(false);
  return (
    <div className="relative hidden sm:block">
      <button onClick={() => setOpen((v) => !v)} className="flex items-center gap-1 p-1 text-[11px] tracking-widest">
        <Globe className="h-4 w-4" />
        {LANG_META[s.lang].native} · {s.currency}
        <ChevronDown className="h-3 w-3" />
      </button>
      {open && (
        <div className="absolute end-0 top-8 z-50 w-44 border border-black/10 bg-white p-3 text-xs shadow-xl">
          <p className="mb-2 text-[10px] uppercase tracking-widest text-mute">{s.t("set.langs")}</p>
          {(s.settings.enabledLangs as Lang[]).map((l) => (
            <button
              key={l}
              onClick={() => {
                s.setLang(l);
                setOpen(false);
              }}
              className={`block w-full py-1 text-start ${s.lang === l ? "font-semibold" : ""}`}
            >
              {LANG_META[l].label}
            </button>
          ))}
          <p className="mb-2 mt-3 text-[10px] uppercase tracking-widest text-mute">{s.t("set.currencies")}</p>
          {(["DZD", "EUR", "USD"] as Currency[]).map((c) => (
            <button
              key={c}
              onClick={() => {
                s.setCurrency(c);
                setOpen(false);
              }}
              className={`block w-full py-1 text-start ${s.currency === c ? "font-semibold" : ""}`}
            >
              {c} ({s.settings.currencies[c].symbol})
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
