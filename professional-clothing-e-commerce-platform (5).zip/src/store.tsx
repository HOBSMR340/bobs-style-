import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { createSeed } from "./seed";
import type {
  ActivityLog,
  AdminUser,
  CartItem,
  Customer,
  Database,
  InventoryMovement,
  Lang,
  MovementType,
  Order,
  OrderStatus,
  Permission,
  Product,
  ProductVariant,
  Settings,
} from "./types";
import { ROLE_PERMISSIONS } from "./types";
import { translations } from "./i18n";

const KEY = "velora-db-v1";

function load(): Database {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Database;
      const seed = createSeed();
      return {
        ...seed,
        ...parsed,
        settings: { ...seed.settings, ...parsed.settings },
        cart: parsed.cart || [],
        wishlist: parsed.wishlist || [],
        currentUser: parsed.currentUser || null,
        currentCustomer: parsed.currentCustomer || null,
        lang: parsed.lang || "fr",
        currency: parsed.currency || "DZD",
      };
    }
  } catch {
    /* ignore */
  }
  return createSeed();
}

function uid(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function effectivePrice(p: Product): number {
  const now = new Date().toISOString();
  if (p.promoPrice && (!p.promoStart || p.promoStart <= now) && (!p.promoEnd || p.promoEnd >= now)) {
    return p.promoPrice;
  }
  return p.salePrice;
}

export function getEffectivePrice(p: Product) {
  return effectivePrice(p);
}

export function productStock(p: Product) {
  return p.variants.reduce((s, v) => s + v.stock, 0);
}

type Store = Database & {
  t: (key: string) => string;
  tr: (v: { fr: string; ar: string; en: string } | undefined) => string;
  dir: "ltr" | "rtl";
  setLang: (l: Lang) => void;
  setCurrency: (c: Database["currency"]) => void;
  formatPrice: (n: number) => string;
  convert: (n: number) => number;
  persist: (patch: Partial<Database>) => void;
  loginAdmin: (email: string, password: string) => AdminUser | null;
  logoutAdmin: () => void;
  loginCustomer: (email: string, password: string) => Customer | null;
  registerCustomer: (c: Omit<Customer, "id" | "createdAt">) => Customer;
  logoutCustomer: () => void;
  hasPermission: (p: Permission) => boolean;
  addToCart: (productId: string, variantId: string, qty?: number) => { ok: boolean; error?: string };
  updateCartQty: (variantId: string, qty: number) => void;
  updateCartVariant: (oldVariantId: string, newVariantId: string) => void;
  removeFromCart: (variantId: string) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  placeOrder: (payload: {
    guest?: Order["guest"];
    address: Order["shippingAddress"];
    paymentMethod: Order["paymentMethod"];
    notes?: string;
  }) => Order;
  updateOrderStatus: (id: string, status: OrderStatus, internalNotes?: string) => void;
  saveProduct: (p: Product) => void;
  duplicateProduct: (id: string) => Product;
  deleteProduct: (id: string) => void;
  hideProduct: (id: string, hidden: boolean) => void;
  adjustStock: (variantId: string, type: MovementType, quantity: number, note?: string) => void;
  bulkUpdatePrices: (ids: string[], percent: number) => void;
  saveSettings: (s: Settings) => void;
  saveUser: (u: AdminUser) => void;
  deleteUser: (id: string) => void;
  log: (action: string, entity: string, entityId: string, details: string) => void;
  resetDemo: () => void;
  markNotifRead: (id: string) => void;
};

const Ctx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<Database>(() => load());

  useEffect(() => {
    try {
      const { currentUser, currentCustomer, ...rest } = db;
      localStorage.setItem(KEY, JSON.stringify({ ...rest, currentUser, currentCustomer }));
    } catch {
      console.warn("Stockage local saturé — réduisez le nombre de photos.");
    }
  }, [db]);

  useEffect(() => {
    document.documentElement.lang = db.lang;
    document.documentElement.dir = db.lang === "ar" ? "rtl" : "ltr";
    document.documentElement.classList.toggle("dark", db.settings.darkMode);
  }, [db.lang, db.settings.darkMode]);

  useEffect(() => {
    const name = db.settings.storeName[db.lang] || db.settings.storeName.fr;
    document.title = name;
    const desc = db.settings.description[db.lang] || db.settings.description.fr;
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "description");
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", desc);
    let fav = document.querySelector('link[rel="icon"]') as HTMLLinkElement | null;
    if (db.settings.favicon) {
      if (!fav) {
        fav = document.createElement("link");
        fav.rel = "icon";
        document.head.appendChild(fav);
      }
      fav.href = db.settings.favicon;
    } else {
      const initials = (name.match(/[A-Za-z]/g) || []).slice(0, 1).join("").toUpperCase() || "V";
      const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' fill='${db.settings.colors.primary}'/><text x='50' y='65' text-anchor='middle' font-size='65' fill='${db.settings.colors.accent}' font-family='Georgia'>${initials}</text></svg>`;
      if (!fav) {
        fav = document.createElement("link");
        fav.rel = "icon";
        document.head.appendChild(fav);
      }
      fav.href = `data:image/svg+xml,${encodeURIComponent(svg)}`;
    }
  }, [db.settings.storeName, db.settings.description, db.settings.colors, db.settings.favicon, db.lang]);

  const persist = useCallback((patch: Partial<Database>) => {
    setDb((prev) => ({ ...prev, ...patch }));
  }, []);

  const log = useCallback((action: string, entity: string, entityId: string, details: string) => {
    setDb((prev) => {
      const entry: ActivityLog = {
        id: uid("act"),
        userId: prev.currentUser?.id || "system",
        userName: prev.currentUser?.name || "Système",
        action,
        entity,
        entityId,
        details,
        createdAt: new Date().toISOString(),
      };
      return { ...prev, activity: [entry, ...prev.activity].slice(0, 400) };
    });
  }, []);

  const setLang = (lang: Lang) => persist({ lang });
  const setCurrency = (currency: Database["currency"]) => persist({ currency });

  const convert = (n: number) => {
    const rate = db.settings.currencies[db.currency]?.rate || 1;
    return n * rate;
  };

  const formatPrice = (n: number) => {
    const cur = db.settings.currencies[db.currency];
    const val = n * (cur?.rate || 1);
    if (db.currency === "DZD") return `${Math.round(val).toLocaleString("fr-FR")} ${cur.symbol}`;
    return `${cur.symbol}${val.toFixed(2)}`;
  };

  const tFn = (key: string) => {
    const row = translations[key];
    if (!row) return key;
    return row[db.lang] || row.fr || key;
  };

  const trFn = (v: { fr: string; ar: string; en: string } | undefined) => {
    if (!v) return "";
    return v[db.lang] || v.fr || "";
  };

  const loginAdmin = (email: string, password: string) => {
    const user = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password && u.active);
    if (!user) return null;
    persist({ currentUser: user });
    log("login", "auth", user.id, `Connexion ${user.email}`);
    return user;
  };

  const logoutAdmin = () => persist({ currentUser: null });

  const loginCustomer = (email: string, password: string) => {
    const c = db.customers.find((x) => x.email.toLowerCase() === email.toLowerCase() && x.password === password);
    if (!c) return null;
    persist({ currentCustomer: c });
    return c;
  };

  const registerCustomer = (data: Omit<Customer, "id" | "createdAt">) => {
    const c: Customer = { ...data, id: uid("c"), createdAt: new Date().toISOString() };
    persist({ customers: [...db.customers, c], currentCustomer: c });
    return c;
  };

  const logoutCustomer = () => persist({ currentCustomer: null });

  const hasPermission = (p: Permission) => {
    if (!db.currentUser) return false;
    if (db.currentUser.role === "super_admin") return true;
    return db.currentUser.permissions.includes(p);
  };

  const addToCart = (productId: string, variantId: string, qty = 1) => {
    const product = db.products.find((p) => p.id === productId);
    const variant = product?.variants.find((v) => v.id === variantId);
    if (!product || !variant) return { ok: false, error: "Produit introuvable" };
    if (variant.stock < qty) return { ok: false, error: "Stock insuffisant" };
    const existing = db.cart.find((i) => i.variantId === variantId);
    let cart: CartItem[];
    if (existing) {
      const next = existing.quantity + qty;
      if (next > variant.stock) return { ok: false, error: "Stock insuffisant" };
      cart = db.cart.map((i) => (i.variantId === variantId ? { ...i, quantity: next } : i));
    } else {
      cart = [...db.cart, { productId, variantId, quantity: qty }];
    }
    persist({ cart });
    return { ok: true };
  };

  const updateCartQty = (variantId: string, qty: number) => {
    if (qty <= 0) {
      persist({ cart: db.cart.filter((i) => i.variantId !== variantId) });
      return;
    }
    persist({ cart: db.cart.map((i) => (i.variantId === variantId ? { ...i, quantity: qty } : i)) });
  };

  const updateCartVariant = (oldVariantId: string, newVariantId: string) => {
    persist({
      cart: db.cart.map((i) => (i.variantId === oldVariantId ? { ...i, variantId: newVariantId } : i)),
    });
  };

  const removeFromCart = (variantId: string) => persist({ cart: db.cart.filter((i) => i.variantId !== variantId) });
  const clearCart = () => persist({ cart: [] });

  const toggleWishlist = (productId: string) => {
    persist({
      wishlist: db.wishlist.includes(productId) ? db.wishlist.filter((id) => id !== productId) : [...db.wishlist, productId],
    });
  };

  const placeOrder = (payload: {
    guest?: Order["guest"];
    address: Order["shippingAddress"];
    paymentMethod: Order["paymentMethod"];
    notes?: string;
  }) => {
    const items = db.cart.map((ci) => {
      const p = db.products.find((x) => x.id === ci.productId)!;
      const v = p.variants.find((x) => x.id === ci.variantId)!;
      const unit = effectivePrice(p);
      return {
        productId: p.id,
        variantId: v.id,
        name: p.name,
        image: p.images[0] || "",
        sku: v.sku,
        size: v.size,
        color: v.color,
        quantity: ci.quantity,
        unitPrice: unit,
        total: unit * ci.quantity,
      };
    });
    const subtotal = items.reduce((s, it) => s + it.total, 0);
    const zone = db.settings.zones.find((z) => z.wilaya === payload.address.wilaya);
    const shipping = subtotal >= db.settings.freeShippingFrom ? 0 : zone?.fee ?? db.settings.shippingFee;
    const tax = db.settings.taxEnabled ? Math.round(subtotal - subtotal / (1 + db.settings.taxRate / 100)) : 0;
    const number = `VL-${String(24000 + db.orders.length + 1)}`;
    const order: Order = {
      id: uid("ord"),
      number,
      customerId: db.currentCustomer?.id,
      guest: payload.guest,
      items,
      subtotal,
      shipping,
      discount: 0,
      tax,
      total: subtotal + shipping,
      status: "new",
      paymentMethod: payload.paymentMethod,
      paymentStatus: "pending",
      shippingAddress: payload.address,
      notes: payload.notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const products = db.products.map((p) => ({
      ...p,
      variants: p.variants.map((v) => {
        const it = items.find((x) => x.variantId === v.id);
        if (!it) return v;
        return { ...v, stock: Math.max(0, v.stock - it.quantity) };
      }),
    }));

    const movements: InventoryMovement[] = items.map((it) => {
      const p = db.products.find((x) => x.id === it.productId)!;
      const v = p.variants.find((x) => x.id === it.variantId)!;
      return {
        id: uid("m"),
        productId: it.productId,
        variantId: it.variantId,
        type: "sale" as MovementType,
        quantity: it.quantity,
        previousStock: v.stock,
        newStock: Math.max(0, v.stock - it.quantity),
        note: `Commande ${number}`,
        userId: "system",
        userName: "Boutique",
        createdAt: new Date().toISOString(),
      };
    });

    persist({
      orders: [order, ...db.orders],
      products,
      movements: [...movements, ...db.movements],
      cart: [],
      notifications: [
        {
          id: uid("n"),
          type: "order",
          title: { fr: "Nouvelle commande", ar: "طلب جديد", en: "New order" },
          message: { fr: `Commande ${number} reçue`, ar: `تم استلام الطلب ${number}`, en: `Order ${number} received` },
          read: false,
          createdAt: new Date().toISOString(),
          link: "#/admin/orders",
        },
        ...db.notifications,
      ],
    });
    return order;
  };

  const updateOrderStatus = (id: string, status: OrderStatus, internalNotes?: string) => {
    persist({
      orders: db.orders.map((o) =>
        o.id === id
          ? {
              ...o,
              status,
              internalNotes: internalNotes ?? o.internalNotes,
              updatedAt: new Date().toISOString(),
              paymentStatus: status === "delivered" ? "paid" : o.paymentStatus,
            }
          : o
      ),
    });
    log("update", "order", id, `Statut → ${status}`);
  };

  const saveProduct = (p: Product) => {
    const exists = db.products.some((x) => x.id === p.id);
    const next = { ...p, updatedAt: new Date().toISOString() };
    persist({
      products: exists ? db.products.map((x) => (x.id === p.id ? next : x)) : [next, ...db.products],
    });
    log(exists ? "update" : "create", "product", p.id, exists ? `Produit modifié : ${p.name.fr}` : `Produit créé : ${p.name.fr}`);
  };

  const duplicateProduct = (id: string) => {
    const src = db.products.find((p) => p.id === id)!;
    const nid = uid("p");
    const copy: Product = {
      ...src,
      id: nid,
      sku: `${src.sku}-COPY`,
      name: { fr: `${src.name.fr} (copie)`, ar: `${src.name.ar} (نسخة)`, en: `${src.name.en} (copy)` },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      variants: src.variants.map((v) => ({
        ...v,
        id: uid("v"),
        productId: nid,
        sku: `${v.sku}-C`,
      })),
    };
    persist({ products: [copy, ...db.products] });
    log("create", "product", copy.id, `Duplication de ${src.name.fr}`);
    return copy;
  };

  const deleteProduct = (id: string) => {
    persist({ products: db.products.filter((p) => p.id !== id) });
    log("delete", "product", id, "Produit supprimé");
  };

  const hideProduct = (id: string, hidden: boolean) => {
    persist({
      products: db.products.map((p) => (p.id === id ? { ...p, status: hidden ? "hidden" : "available" } : p)),
    });
  };

  const adjustStock = (variantId: string, type: MovementType, quantity: number, note?: string) => {
    let movement: InventoryMovement | null = null;
    const products = db.products.map((p) => ({
      ...p,
      variants: p.variants.map((v) => {
        if (v.id !== variantId) return v;
        let next = v.stock;
        if (type === "in" || type === "return") next = v.stock + quantity;
        else if (type === "out" || type === "sale") next = Math.max(0, v.stock - quantity);
        else next = quantity;
        movement = {
          id: uid("m"),
          productId: p.id,
          variantId: v.id,
          type,
          quantity,
          previousStock: v.stock,
          newStock: next,
          note,
          userId: db.currentUser?.id || "system",
          userName: db.currentUser?.name || "Système",
          createdAt: new Date().toISOString(),
        };
        return { ...v, stock: next };
      }),
    }));
    persist({ products, movements: movement ? [movement, ...db.movements] : db.movements });
    log("update", "stock", variantId, `Stock ${type} ${quantity}`);
  };

  const bulkUpdatePrices = (ids: string[], percent: number) => {
    persist({
      products: db.products.map((p) => {
        if (!ids.includes(p.id)) return p;
        const factor = 1 + percent / 100;
        return {
          ...p,
          salePrice: Math.round(p.salePrice * factor),
          oldPrice: p.oldPrice ? Math.round(p.oldPrice * factor) : p.oldPrice,
          promoPrice: p.promoPrice ? Math.round(p.promoPrice * factor) : p.promoPrice,
          updatedAt: new Date().toISOString(),
        };
      }),
    });
    log("update", "price", ids.join(","), `Prix ${percent > 0 ? "+" : ""}${percent}% sur ${ids.length} produits`);
  };

  const saveSettings = (settings: Settings) => {
    persist({ settings });
    log("update", "settings", "settings", "Configuration mise à jour");
  };

  const saveUser = (u: AdminUser) => {
    const exists = db.users.some((x) => x.id === u.id);
    const withPerm: AdminUser = { ...u, permissions: u.permissions.length ? u.permissions : [...ROLE_PERMISSIONS[u.role]] };
    persist({ users: exists ? db.users.map((x) => (x.id === u.id ? withPerm : x)) : [...db.users, withPerm] });
    log(exists ? "update" : "create", "user", u.id, `Utilisateur ${u.email}`);
  };

  const deleteUser = (id: string) => {
    persist({ users: db.users.filter((u) => u.id !== id) });
    log("delete", "user", id, "Utilisateur supprimé");
  };

  const resetDemo = () => {
    const fresh = createSeed();
    persist({ ...fresh, lang: db.lang, currency: db.currency });
  };

  const markNotifRead = (id: string) => {
    persist({ notifications: db.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)) });
  };

  const value = useMemo<Store>(
    () => ({
      ...db,
      t: tFn,
      tr: trFn,
      dir: db.lang === "ar" ? "rtl" : "ltr",
      setLang,
      setCurrency,
      formatPrice,
      convert,
      persist,
      loginAdmin,
      logoutAdmin,
      loginCustomer,
      registerCustomer,
      logoutCustomer,
      hasPermission,
      addToCart,
      updateCartQty,
      updateCartVariant,
      removeFromCart,
      clearCart,
      toggleWishlist,
      placeOrder,
      updateOrderStatus,
      saveProduct,
      duplicateProduct,
      deleteProduct,
      hideProduct,
      adjustStock,
      bulkUpdatePrices,
      saveSettings,
      saveUser,
      deleteUser,
      log,
      resetDemo,
      markNotifRead,
    }),
    [db]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}

export function findVariant(p: Product, size?: string, color?: string): ProductVariant | undefined {
  return p.variants.find((v) => (!size || v.size === size) && (!color || v.color === color));
}
