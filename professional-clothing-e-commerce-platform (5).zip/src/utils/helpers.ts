import type { Product } from "../types";

export function uid(prefix = "id") {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export function effectivePrice(p: Product): number {
  const now = new Date().toISOString();
  if (p.promoPrice && (!p.promoStart || p.promoStart <= now) && (!p.promoEnd || p.promoEnd >= now)) {
    return p.promoPrice;
  }
  return p.salePrice;
}

export function discountPercent(p: Product): number {
  const old = p.oldPrice || p.salePrice;
  const now = effectivePrice(p);
  if (!old || old <= now) return p.promoPercent || 0;
  return Math.round(((old - now) / old) * 100);
}

export function isOnSale(p: Product) {
  return discountPercent(p) > 0 && effectivePrice(p) < (p.oldPrice || p.salePrice);
}

export function productStock(p: Product) {
  return p.variants.reduce((s, v) => s + v.stock, 0);
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function downloadText(filename: string, content: string, mime = "text/plain") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function toCSV(rows: (string | number)[][]) {
  return rows
    .map((r) =>
      r
        .map((c) => {
          const s = String(c ?? "");
          return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
        })
        .join(";")
    )
    .join("\n");
}

export function exportCSV(filename: string, rows: (string | number)[][]) {
  downloadText(filename, "\uFEFF" + toCSV(rows), "text/csv;charset=utf-8");
}

export function printPDF(title: string, html: string) {
  const w = window.open("", "_blank", "width=900,height=700");
  if (!w) return;
  w.document.write(`<!doctype html><html><head><title>${title}</title>
    <style>
      body{font-family:Georgia,serif;padding:32px;color:#1a1a1a}
      h1{font-size:22px;letter-spacing:.2em;text-transform:uppercase}
      table{width:100%;border-collapse:collapse;margin-top:16px;font-size:12px}
      th,td{border-bottom:1px solid #ddd;padding:8px;text-align:left}
      th{text-transform:uppercase;letter-spacing:.08em;font-size:10px;color:#666}
    </style></head><body>${html}</body></html>`);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 300);
}

export function formatDate(iso: string, lang: string) {
  try {
    return new Date(iso).toLocaleString(lang === "ar" ? "ar-DZ" : lang === "en" ? "en-GB" : "fr-FR", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

export function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export const WILAYA_LIST = [
  "Adrar","Chlef","Laghouat","Oum El Bouaghi","Batna","Béjaïa","Biskra","Béchar","Blida","Bouira",
  "Tamanrasset","Tébessa","Tlemcen","Tiaret","Tizi Ouzou","Alger","Djelfa","Jijel","Sétif","Saïda",
  "Skikda","Sidi Bel Abbès","Annaba","Guelma","Constantine","Médéa","Mostaganem","M'Sila","Mascara","Ouargla",
  "Oran","El Bayadh","Illizi","Bordj Bou Arréridj","Boumerdès","El Tarf","Tindouf","Tissemsilt","El Oued","Khenchela",
  "Souk Ahras","Tipaza","Mila","Aïn Defla","Naâma","Aïn Témouchent","Ghardaïa","Relizane",
];
