export type Lang = "fr" | "ar" | "en";
export type Currency = "DZD" | "EUR" | "USD";
export type Role = "super_admin" | "manager" | "seller" | "stock_manager";
export type ProductStatus = "available" | "out_of_stock" | "hidden";
export type Gender = "homme" | "femme" | "enfant" | "unisexe";
export type OrderStatus =
  | "new"
  | "confirmed"
  | "preparing"
  | "shipped"
  | "delivered"
  | "cancelled"
  | "returned";
export type MovementType = "in" | "out" | "adjust" | "sale" | "return";
export type PaymentMethod = "cod" | "card" | "online" | "other";

export interface Translation {
  fr: string;
  ar: string;
  en: string;
}

export interface ProductVariant {
  id: string;
  productId: string;
  size: string;
  color: string;
  colorHex: string;
  sku: string;
  stock: number;
  minStock: number;
  image?: string;
}

export interface Product {
  id: string;
  name: Translation;
  description: Translation;
  images: string[];
  video?: string;
  categoryId: string;
  subcategoryId?: string;
  brandId: string;
  sku: string;
  purchasePrice: number;
  salePrice: number;
  oldPrice?: number;
  promoPrice?: number;
  promoPercent?: number;
  promoStart?: string;
  promoEnd?: string;
  material?: Translation;
  gender: Gender;
  ageRange?: string;
  weight?: number;
  dimensions?: string;
  tags: string[];
  status: ProductStatus;
  createdAt: string;
  updatedAt: string;
  featured?: boolean;
  isNew?: boolean;
  variants: ProductVariant[];
  sizes: string[];
  colors: { name: string; hex: string }[];
}

export interface Category {
  id: string;
  slug: string;
  name: Translation;
  image: string;
  parentId?: string;
}

export interface Brand {
  id: string;
  name: string;
}

export interface InventoryMovement {
  id: string;
  productId: string;
  variantId: string;
  type: MovementType;
  quantity: number;
  previousStock: number;
  newStock: number;
  note?: string;
  userId: string;
  userName: string;
  createdAt: string;
}

export interface Customer {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  password: string;
  address: string;
  city: string;
  wilaya: string;
  createdAt: string;
}

export interface CartItem {
  productId: string;
  variantId: string;
  quantity: number;
}

export interface OrderItem {
  productId: string;
  variantId: string;
  name: Translation;
  image: string;
  sku: string;
  size: string;
  color: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Order {
  id: string;
  number: string;
  customerId?: string;
  guest?: {
    firstName: string;
    lastName: string;
    phone: string;
    email: string;
  };
  items: OrderItem[];
  subtotal: number;
  shipping: number;
  discount: number;
  tax: number;
  total: number;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: "pending" | "paid" | "failed" | "refunded";
  shippingAddress: {
    firstName: string;
    lastName: string;
    phone: string;
    email: string;
    address: string;
    city: string;
    wilaya: string;
  };
  notes?: string;
  internalNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AdminUser {
  id: string;
  email: string;
  password: string;
  name: string;
  role: Role;
  permissions: string[];
  active: boolean;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  entity: string;
  entityId: string;
  details: string;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  type: "order" | "stock" | "system";
  title: Translation;
  message: Translation;
  read: boolean;
  createdAt: string;
  link?: string;
}

export interface ShippingZone {
  wilaya: string;
  fee: number;
  delay: string;
}

export interface Settings {
  storeName: Translation;
  logo: string;
  favicon: string;
  description: Translation;
  email: string;
  phone: string;
  address: string;
  social: { instagram: string; facebook: string; tiktok: string };
  colors: { primary: string; accent: string };
  font: string;
  buttonStyle: "rounded" | "square" | "pill";
  banner: string;
  bannerText: Translation;
  darkMode: boolean;
  defaultLang: Lang;
  enabledLangs: Lang[];
  defaultCurrency: Currency;
  currencies: Record<Currency, { rate: number; symbol: string }>;
  shippingFee: number;
  freeShippingFrom: number;
  zones: ShippingZone[];
  payments: { cod: boolean; card: boolean; online: boolean; other: boolean };
  taxEnabled: boolean;
  taxRate: number;
  pricesIncludeTax: boolean;
  notifications: {
    newOrder: boolean;
    confirmed: boolean;
    shipped: boolean;
    delivered: boolean;
    lowStock: boolean;
    outOfStock: boolean;
  };
}

export interface Database {
  products: Product[];
  categories: Category[];
  brands: Brand[];
  customers: Customer[];
  orders: Order[];
  users: AdminUser[];
  movements: InventoryMovement[];
  settings: Settings;
  activity: ActivityLog[];
  notifications: AppNotification[];
  cart: CartItem[];
  wishlist: string[];
  currentUser: AdminUser | null;
  currentCustomer: Customer | null;
  lang: Lang;
  currency: Currency;
}

export const ALL_PERMISSIONS = [
  "dashboard",
  "products",
  "stock",
  "prices",
  "orders",
  "customers",
  "reports",
  "settings",
  "users",
  "activity",
] as const;

export type Permission = (typeof ALL_PERMISSIONS)[number];

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  super_admin: [...ALL_PERMISSIONS],
  manager: ["dashboard", "products", "stock", "prices", "orders", "customers", "reports"],
  seller: ["dashboard", "orders", "customers"],
  stock_manager: ["dashboard", "stock"],
};
